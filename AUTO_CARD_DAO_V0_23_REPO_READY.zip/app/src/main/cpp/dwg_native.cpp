
#include <jni.h>
#include <string>
#include <vector>
#include <cstring>

static std::string detect_version(const unsigned char* data, size_t len) {
    if (!data || len < 6) return "";
    return std::string(reinterpret_cast<const char*>(data), 6);
}

extern "C"
JNIEXPORT jstring JNICALL
Java_com_dao_autocard_cad_io_DwgNativeBridge_nativeVersion(
        JNIEnv* env, jclass, jbyteArray bytes) {
    if (!bytes) return env->NewStringUTF("");

    jsize len = env->GetArrayLength(bytes);
    std::vector<jbyte> buf((size_t)len);
    env->GetByteArrayRegion(bytes, 0, len, buf.data());

    std::string v = detect_version(
            reinterpret_cast<const unsigned char*>(buf.data()),
            (size_t)len);

    return env->NewStringUTF(v.c_str());
}

extern "C"
JNIEXPORT jboolean JNICALL
Java_com_dao_autocard_cad_io_DwgNativeBridge_nativeSupports(
        JNIEnv* env, jclass, jbyteArray bytes) {
    if (!bytes) return JNI_FALSE;

    jsize len = env->GetArrayLength(bytes);
    if (len < 6) return JNI_FALSE;

    jbyte head[6];
    env->GetByteArrayRegion(bytes, 0, 6, head);
    return (head[0]=='A' && head[1]=='C' && head[2]=='1' && head[3]=='0')
            ? JNI_TRUE : JNI_FALSE;
}

extern "C"
JNIEXPORT jstring JNICALL
Java_com_dao_autocard_cad_io_DwgNativeBridge_nativeParseSummary(
        JNIEnv* env, jclass, jbyteArray bytes) {
    if (!bytes) return env->NewStringUTF("{\"ok\":false,\"error\":\"empty\"}");

    jsize len = env->GetArrayLength(bytes);
    std::vector<jbyte> buf((size_t)len);
    env->GetByteArrayRegion(bytes, 0, len, buf.data());

    std::string ver = detect_version(
            reinterpret_cast<const unsigned char*>(buf.data()),
            (size_t)len);

    // Placeholder JSON from native side. The production DWG decoder will
    // replace this body while keeping the JNI contract stable.
    std::string json =
            std::string("{\"ok\":true,\"version\":\"") +
            ver +
            "\",\"native\":true,\"decoder\":\"placeholder\",\"entities\":0,\"layers\":0}";

    return env->NewStringUTF(json.c_str());
}
