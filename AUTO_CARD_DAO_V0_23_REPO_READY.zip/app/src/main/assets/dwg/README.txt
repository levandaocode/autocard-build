AUTO CARD DAO V0.22 OFFLINE DWG
DWG engine is loaded only from app assets.
No CAD drawing is uploaded to a server.
The production acad-engine.js bundle must be packaged here before release.
