package com.dao.autocard.cad.history;

import com.dao.autocard.cad.model.*;

public final class DuplicateEntityCommand implements EditCommand {
    private final DrawingDocument doc;
    private final CadEntity source;
    private CadEntity copy;

    public DuplicateEntityCommand(DrawingDocument doc,CadEntity source){ this.doc=doc; this.source=source; }

    public CadEntity getCopy(){ return copy; }

    @Override public void execute(){
        if(doc==null || source==null) return;
        if(copy==null) copy=new EntityCloner().cloneEntity(source);
        if(copy!=null && doc.indexOf(copy)<0) doc.add(copy);
    }

    @Override public void undo(){ if(doc!=null && copy!=null) doc.remove(copy); }
    @Override public String getLabel(){ return "Nhân bản đối tượng"; }
}
