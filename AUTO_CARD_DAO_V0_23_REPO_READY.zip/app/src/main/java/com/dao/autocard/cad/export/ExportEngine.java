package com.dao.autocard.cad.export;

import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.pdf.PdfDocument;
import android.view.View;

import java.io.*;

public class ExportEngine {

    public File exportPng(View view, File target) throws IOException {
        if (view == null) throw new IllegalArgumentException("view == null");
        int w = Math.max(1, view.getWidth());
        int h = Math.max(1, view.getHeight());

        Bitmap bitmap = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888);
        Canvas canvas = new Canvas(bitmap);
        view.draw(canvas);

        try (FileOutputStream out = new FileOutputStream(target)) {
            if (!bitmap.compress(Bitmap.CompressFormat.PNG, 100, out)) {
                throw new IOException("PNG compression failed");
            }
        } finally {
            bitmap.recycle();
        }
        return target;
    }

    public File exportPdf(View view, File target) throws IOException {
        if (view == null) throw new IllegalArgumentException("view == null");

        int w = Math.max(1, view.getWidth());
        int h = Math.max(1, view.getHeight());

        PdfDocument pdf = new PdfDocument();
        try {
            PdfDocument.PageInfo info = new PdfDocument.PageInfo.Builder(w, h, 1).create();
            PdfDocument.Page page = pdf.startPage(info);
            view.draw(page.getCanvas());
            pdf.finishPage(page);

            try (FileOutputStream out = new FileOutputStream(target)) {
                pdf.writeTo(out);
            }
        } finally {
            pdf.close();
        }
        return target;
    }
}
