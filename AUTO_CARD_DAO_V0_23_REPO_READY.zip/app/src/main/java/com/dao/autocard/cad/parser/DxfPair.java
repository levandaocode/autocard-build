package com.dao.autocard.cad.parser;

final class DxfPair {
    final int code;
    final String value;

    DxfPair(int code, String value) {
        this.code = code;
        this.value = value;
    }

    double asDouble(double fallback) {
        try { return Double.parseDouble(value.trim()); }
        catch (Exception e) { return fallback; }
    }

    int asInt(int fallback) {
        try { return Integer.parseInt(value.trim()); }
        catch (Exception e) { return fallback; }
    }
}
