package com.dao.autocard.cad.io;

public enum CadFileType {
    DXF,
    DWG,
    UNKNOWN
}
