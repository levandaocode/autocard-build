package com.dao.autocard.cad.io;

import com.dao.autocard.cad.model.DrawingDocument;
import java.io.*;

public interface DwgEngine {
    boolean supportsVersion(String versionCode);
    DrawingDocument read(InputStream in) throws Exception;
}
