package com.dao.autocard.cad.model;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class DrawingDocument {
    private final List<CadEntity> entities = new ArrayList<>();
    private final java.util.Map<String, BlockDefinition> blocks = new java.util.LinkedHashMap<>();
    private String unit = "mm";
    private double scale = 1.0;

    public void add(CadEntity entity) {
        if (entity != null) entities.add(entity);
    }

    public void add(int index, CadEntity entity) {
        if (entity == null) return;
        if (index < 0 || index > entities.size()) entities.add(entity);
        else entities.add(index, entity);
    }

    public boolean remove(CadEntity entity) {
        return entities.remove(entity);
    }

    public int indexOf(CadEntity entity) {
        return entities.indexOf(entity);
    }

    public List<CadEntity> getEntities() {
        return Collections.unmodifiableList(entities);
    }


    public void addBlock(BlockDefinition block) {
        if (block != null && block.name != null) blocks.put(block.name, block);
    }

    public BlockDefinition getBlock(String name) {
        return blocks.get(name);
    }

    public java.util.Map<String, BlockDefinition> getBlocks() {
        return java.util.Collections.unmodifiableMap(blocks);
    }


    public DrawingBounds getBounds() {
        DrawingBounds b = new DrawingBounds();
        for (CadEntity entity : entities) {
            if (entity instanceof LineEntity) {
                LineEntity e = (LineEntity) entity;
                b.include(e.start.x, e.start.y);
                b.include(e.end.x, e.end.y);
            } else if (entity instanceof CircleEntity) {
                CircleEntity e = (CircleEntity) entity;
                b.include(e.center.x - e.radius, e.center.y - e.radius);
                b.include(e.center.x + e.radius, e.center.y + e.radius);
            } else if (entity instanceof ArcEntity) {
                ArcEntity e = (ArcEntity) entity;
                b.include(e.center.x - e.radius, e.center.y - e.radius);
                b.include(e.center.x + e.radius, e.center.y + e.radius);
            } else if (entity instanceof PolylineEntity) {
                PolylineEntity e = (PolylineEntity) entity;
                for (Point2D pt : e.getPoints()) b.include(pt.x, pt.y);
            } else if (entity instanceof TextEntity) {
                TextEntity e = (TextEntity) entity;
                b.include(e.position.x, e.position.y);
            } else if (entity instanceof EllipseEntity) {
                EllipseEntity e = (EllipseEntity) entity;
                double r = Math.max(e.majorRadius(), e.minorRadius());
                b.include(e.center.x-r, e.center.y-r);
                b.include(e.center.x+r, e.center.y+r);
            } else if (entity instanceof SplineEntity) {
                SplineEntity e = (SplineEntity) entity;
                for (Point2D pt : e.getControlPoints()) b.include(pt.x, pt.y);
                for (Point2D pt : e.getFitPoints()) b.include(pt.x, pt.y);
            } else if (entity instanceof InsertEntity) {
                InsertEntity e = (InsertEntity) entity;
                b.include(e.position.x, e.position.y);
            } else if (entity instanceof DimensionEntity) {
                DimensionEntity e = (DimensionEntity) entity;
                b.include(e.definitionPoint.x, e.definitionPoint.y);
                b.include(e.textPoint.x, e.textPoint.y);
            } else if (entity instanceof HatchEntity) {
                HatchEntity e = (HatchEntity) entity;
                for (java.util.List<Point2D> loop : e.getLoops())
                    for (Point2D pt : loop) b.include(pt.x, pt.y);
            } else if (entity instanceof LeaderEntity) {
                LeaderEntity e = (LeaderEntity) entity;
                for (Point2D pt : e.getPoints()) b.include(pt.x, pt.y);
            }
        }
        return b;
    }

    public String getUnit() { return unit; }
    public void setUnit(String unit) { this.unit = unit; }

    public double getScale() { return scale; }
    public void setScale(double scale) {
        if (scale > 0) this.scale = scale;
    }
}
