
package com.dao.autocard.cad.io;

import android.annotation.SuppressLint;
import android.content.Context;
import android.util.Base64;
import android.webkit.JavascriptInterface;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

public final class DwgWebEngineView extends WebView {

    public interface Listener {
        void onReady();
        void onRendered(int entityCount, int layerCount, String version);
        void onError(String message);
    }

    private Listener listener;
    private boolean engineReady = false;
    private String pendingBase64;
    private String pendingName;

    @SuppressLint({"SetJavaScriptEnabled","AddJavascriptInterface"})
    public DwgWebEngineView(Context context) {
        super(context);

        WebSettings s = getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(false);
        s.setAllowContentAccess(false);
        s.setBuiltInZoomControls(true);
        s.setDisplayZoomControls(false);
        s.setSupportZoom(true);
        s.setLoadWithOverviewMode(true);
        s.setUseWideViewPort(true);

        addJavascriptInterface(new Bridge(), "AndroidDwg");
        setWebViewClient(new WebViewClient());

        loadDataWithBaseURL(
                "file:///android_asset/dwg/",
                buildHtml(),
                "text/html",
                "UTF-8",
                null
        );
    }

    public void setListener(Listener listener) {
        this.listener = listener;
    }

    public boolean isEngineReady() {
        return engineReady;
    }

    public void renderDwg(byte[] data, String displayName) {
        if (data == null || data.length == 0) {
            if (listener != null) listener.onError("File DWG rỗng");
            return;
        }

        pendingBase64 = Base64.encodeToString(data, Base64.NO_WRAP);
        pendingName = displayName == null ? "Bản vẽ DWG" : displayName;

        if (engineReady) dispatchPending();
    }

    private void dispatchPending() {
        if (!engineReady || pendingBase64 == null) return;

        String b64 = pendingBase64;
        String name = pendingName;
        pendingBase64 = null;
        pendingName = null;

        String safeName = name.replace("\\", "\\\\").replace("'", "\\'");
        String js = "window.AutoCardDwg.parse('" + b64 + "','" + safeName + "')";
        evaluateJavascript(js, null);
    }

    private final class Bridge {
        @JavascriptInterface public void ready() {
            post(() -> {
                engineReady = true;
                if (listener != null) listener.onReady();
                dispatchPending();
            });
        }

        @JavascriptInterface public void rendered(int entities, int layers, String version) {
            post(() -> {
                if (listener != null) listener.onRendered(entities, layers, version);
            });
        }

        @JavascriptInterface public void error(String message) {
            post(() -> {
                if (listener != null) listener.onError(message);
            });
        }
    }

    private String buildHtml() {
        return "<!doctype html><html><head>" +
                "<meta charset='utf-8'>" +
                "<meta name='viewport' content='width=device-width,initial-scale=1,maximum-scale=5'>" +
                "<style>" +
                "html,body{margin:0;width:100%;height:100%;overflow:auto;background:#fff}" +
                "#stage{width:100%;height:100%;display:flex;align-items:center;justify-content:center}" +
                "#stage svg{max-width:100%;max-height:100%;width:100%;height:100%}" +
                "#msg{position:fixed;left:12px;top:12px;padding:8px 12px;background:#ffffffdd;" +
                "font:14px sans-serif;border-radius:8px;box-shadow:0 1px 6px #999}" +
                "</style></head><body>" +
                "<div id='stage'></div><div id='msg'>Đang tải DWG Engine...</div>" +
                "<script type='module'>" +
                "try{" +
                " const A=await import('file:///android_asset/dwg/acad-engine.js');" +
                " const msg=document.getElementById('msg');" +
                " msg.textContent='DWG Engine sẵn sàng';" +
                " window.AutoCardDwg={" +
                "   parse:async function(b64,name){" +
                "     try{" +
                "       msg.textContent='Đang giải mã '+name+'...';" +
                "       const bin=atob(b64);" +
                "       const bytes=new Uint8Array(bin.length);" +
                "       for(let i=0;i<bin.length;i++) bytes[i]=bin.charCodeAt(i);" +
                "       const notes=[];" +
                "       const doc=A.DwgReader.ReadFromStream(bytes.buffer,(sender,e)=>{" +
                "         if(e&&e.Message) notes.push(String(e.Message));" +
                "       });" +
                "       let entities=0;" +
                "       try{ for(const e of doc.modelSpace.entities) entities++; }catch(_e){}" +
                "       let layers=0;" +
                "       try{ for(const l of doc.layers) layers++; }catch(_e){" +
                "         try{ layers=doc.layers.count||0; }catch(__e){}" +
                "       }" +
                "       let size=4*1024*1024;" +
                "       if(bytes.length>512*1024) size=Math.max(size,bytes.length*16);" +
                "       const output=new Uint8Array(size);" +
                "       const writer=new A.SvgWriter(output,doc);" +
                "       writer.Write();" +
                "       let end=output.indexOf(0);" +
                "       if(end<0) end=output.length;" +
                "       let svg=new TextDecoder('utf-8').decode(output.subarray(0,end)).trim();" +
                "       if(!svg.startsWith('<svg')&&!svg.startsWith('<?xml')){" +
                "         throw new Error('Engine đã đọc DWG nhưng chưa tạo được SVG');" +
                "       }" +
                "       document.getElementById('stage').innerHTML=svg;" +
                "       msg.style.display='none';" +
                "       let version='';" +
                "       try{version=String(doc.header.version||'');}catch(_e){}" +
                "       AndroidDwg.rendered(entities,layers,version);" +
                "     }catch(err){" +
                "       msg.style.display='block';" +
                "       msg.textContent='Lỗi DWG: '+(err&&err.message?err.message:String(err));" +
                "       AndroidDwg.error(err&&err.stack?String(err.stack):String(err));" +
                "     }" +
                "   }" +
                " };" +
                " AndroidDwg.ready();" +
                "}catch(err){" +
                " document.getElementById('msg').textContent='Không tải được DWG Engine';" +
                " AndroidDwg.error('Không tải được DWG Engine: '+(err&&err.message?err.message:String(err)));" +
                "}" +
                "</script></body></html>";
    }
}
