package com.dao.autocard.cad.model;

public final class EntityCloner {
    public CadEntity cloneEntity(CadEntity e) {
        if (e instanceof LineEntity) {
            LineEntity x=(LineEntity)e;
            LineEntity c=new LineEntity(new Point2D(x.start.x,x.start.y),new Point2D(x.end.x,x.end.y));
            c.setLayer(x.getLayer()); return c;
        }
        if (e instanceof CircleEntity) {
            CircleEntity x=(CircleEntity)e;
            CircleEntity c=new CircleEntity(new Point2D(x.center.x,x.center.y),x.radius);
            c.setLayer(x.getLayer()); return c;
        }
        if (e instanceof ArcEntity) {
            ArcEntity x=(ArcEntity)e;
            ArcEntity c=new ArcEntity(new Point2D(x.center.x,x.center.y),x.radius,x.startAngleDeg,x.endAngleDeg);
            c.setLayer(x.getLayer()); return c;
        }
        if (e instanceof PolylineEntity) {
            PolylineEntity x=(PolylineEntity)e;
            PolylineEntity c=new PolylineEntity();
            for(Point2D p:x.getPoints()) c.addPoint(new Point2D(p.x,p.y));
            c.setClosed(x.isClosed()); c.setLayer(x.getLayer()); return c;
        }
        if (e instanceof TextEntity) {
            TextEntity x=(TextEntity)e;
            TextEntity c=new TextEntity(x.getType(),new Point2D(x.position.x,x.position.y),x.text,x.height,x.rotationDeg);
            c.setLayer(x.getLayer()); return c;
        }
        if (e instanceof InsertEntity) {
            InsertEntity x=(InsertEntity)e;
            InsertEntity c=new InsertEntity(x.blockName,new Point2D(x.position.x,x.position.y),x.scaleX,x.scaleY,x.rotationDeg);
            c.setLayer(x.getLayer()); return c;
        }
        return null;
    }
}
