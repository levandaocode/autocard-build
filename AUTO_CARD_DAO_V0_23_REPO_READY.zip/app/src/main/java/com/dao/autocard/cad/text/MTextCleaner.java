package com.dao.autocard.cad.text;

public final class MTextCleaner {
    public String clean(String input) {
        if (input == null) return "";
        String s = input;

        // DXF MTEXT paragraph/nonbreaking-space escapes.
        s = s.replace("\\P", "\n");
        s = s.replace("\\p", "\n");
        s = s.replace("\\~", " ");

        // Escaped braces/backslash.
        s = s.replace("\\{", "{");
        s = s.replace("\\}", "}");

        // Strip simple MTEXT formatting commands ending in ';'
        // e.g. \H1.2x; \W0.8; \C1; \FArial|b0|i0;
        s = s.replaceAll("\\\\[AaCcFfHhLlOoPpQqSsTtWw][^;]*;", "");

        // Remove grouping braces left by inline formatting.
        s = s.replace("{", "").replace("}", "");

        return s;
    }
}
