package com.dao.autocard.cad.model;

public final class TextEntity extends CadEntity {
    public final Point2D position;
    public final String text;
    public final double height;
    public final double rotationDeg;

    public TextEntity(EntityType type, Point2D position, String text, double height, double rotationDeg) {
        super(type == EntityType.MTEXT ? EntityType.MTEXT : EntityType.TEXT);
        this.position = position;
        this.text = text == null ? "" : text;
        this.height = height;
        this.rotationDeg = rotationDeg;
    }
}
