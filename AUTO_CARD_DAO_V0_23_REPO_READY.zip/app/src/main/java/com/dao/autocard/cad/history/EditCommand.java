package com.dao.autocard.cad.history;

public interface EditCommand {
    void execute();
    void undo();
    String getLabel();
}
