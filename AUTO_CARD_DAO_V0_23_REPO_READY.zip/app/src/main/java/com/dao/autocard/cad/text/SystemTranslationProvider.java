package com.dao.autocard.cad.text;

import android.content.Context;
import android.os.Build;

public final class SystemTranslationProvider implements TranslationProvider {
    private final Context context;

    public SystemTranslationProvider(Context context) {
        this.context = context.getApplicationContext();
    }

    @Override
    public void translate(String text, String sourceLanguage, String targetLanguage, Callback callback) {
        if (callback == null) return;

        // Android system TranslationService differs by OEM/device.
        // V0.5 keeps this bridge fail-safe and does not crash devices without service.
        if (Build.VERSION.SDK_INT < 31) {
            callback.onFailure(new UnsupportedOperationException("System translation requires Android 12+"));
            return;
        }

        // Real TranslationManager wiring will be finalized after device testing.
        callback.onFailure(new UnsupportedOperationException("No compatible TranslationService bound"));
    }
}
