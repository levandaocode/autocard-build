package com.dao.autocard.cad.viewer;

import com.dao.autocard.cad.model.*;
import java.util.*;

public final class GripManager {
    public List<Point2D> getGrips(CadEntity e) {
        List<Point2D> out = new ArrayList<>();
        if (e instanceof LineEntity) {
            LineEntity x=(LineEntity)e;
            out.add(x.start); out.add(x.end);
        } else if (e instanceof CircleEntity) {
            CircleEntity x=(CircleEntity)e;
            out.add(x.center);
            out.add(new Point2D(x.center.x+x.radius,x.center.y));
        } else if (e instanceof ArcEntity) {
            ArcEntity x=(ArcEntity)e;
            out.add(x.center);
        } else if (e instanceof PolylineEntity) {
            out.addAll(((PolylineEntity)e).getPoints());
        } else if (e instanceof TextEntity) {
            out.add(((TextEntity)e).position);
        } else if (e instanceof InsertEntity) {
            out.add(((InsertEntity)e).position);
        }
        return out;
    }
}
