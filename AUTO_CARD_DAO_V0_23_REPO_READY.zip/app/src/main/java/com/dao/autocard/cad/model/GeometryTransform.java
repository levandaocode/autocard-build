package com.dao.autocard.cad.model;

public final class GeometryTransform {

    public CadEntity move(CadEntity e,double dx,double dy){
        if(e instanceof LineEntity){
            LineEntity x=(LineEntity)e;
            LineEntity n=new LineEntity(p(x.start,dx,dy),p(x.end,dx,dy)); n.setLayer(e.getLayer()); return n;
        }
        if(e instanceof CircleEntity){
            CircleEntity x=(CircleEntity)e;
            CircleEntity n=new CircleEntity(p(x.center,dx,dy),x.radius); n.setLayer(e.getLayer()); return n;
        }
        if(e instanceof ArcEntity){
            ArcEntity x=(ArcEntity)e;
            ArcEntity n=new ArcEntity(p(x.center,dx,dy),x.radius,x.startAngleDeg,x.endAngleDeg); n.setLayer(e.getLayer()); return n;
        }
        if(e instanceof PolylineEntity){
            PolylineEntity x=(PolylineEntity)e; PolylineEntity n=new PolylineEntity();
            for(Point2D q:x.getPoints()) n.addPoint(p(q,dx,dy));
            n.setClosed(x.isClosed()); n.setLayer(e.getLayer()); return n;
        }
        if(e instanceof TextEntity){
            TextEntity x=(TextEntity)e;
            TextEntity n=new TextEntity(x.getType(),p(x.position,dx,dy),x.text,x.height,x.rotationDeg); n.setLayer(e.getLayer()); return n;
        }
        if(e instanceof InsertEntity){
            InsertEntity x=(InsertEntity)e;
            InsertEntity n=new InsertEntity(x.blockName,p(x.position,dx,dy),x.scaleX,x.scaleY,x.rotationDeg); n.setLayer(e.getLayer()); return n;
        }
        return e;
    }

    public CadEntity rotate(CadEntity e,double angleDeg,Point2D pivot){
        if(pivot==null) pivot=new Point2D(0,0);
        if(e instanceof LineEntity){
            LineEntity x=(LineEntity)e;
            LineEntity n=new LineEntity(r(x.start,angleDeg,pivot),r(x.end,angleDeg,pivot)); n.setLayer(e.getLayer()); return n;
        }
        if(e instanceof CircleEntity){
            CircleEntity x=(CircleEntity)e;
            CircleEntity n=new CircleEntity(r(x.center,angleDeg,pivot),x.radius); n.setLayer(e.getLayer()); return n;
        }
        if(e instanceof ArcEntity){
            ArcEntity x=(ArcEntity)e;
            ArcEntity n=new ArcEntity(r(x.center,angleDeg,pivot),x.radius,x.startAngleDeg+angleDeg,x.endAngleDeg+angleDeg); n.setLayer(e.getLayer()); return n;
        }
        if(e instanceof TextEntity){
            TextEntity x=(TextEntity)e;
            TextEntity n=new TextEntity(x.getType(),r(x.position,angleDeg,pivot),x.text,x.height,x.rotationDeg+angleDeg); n.setLayer(e.getLayer()); return n;
        }
        if(e instanceof InsertEntity){
            InsertEntity x=(InsertEntity)e;
            InsertEntity n=new InsertEntity(x.blockName,r(x.position,angleDeg,pivot),x.scaleX,x.scaleY,x.rotationDeg+angleDeg); n.setLayer(e.getLayer()); return n;
        }
        return e;
    }

    public CadEntity scale(CadEntity e,double factor,Point2D pivot){
        if(factor<=0) return e;
        if(pivot==null) pivot=new Point2D(0,0);
        if(e instanceof LineEntity){
            LineEntity x=(LineEntity)e;
            LineEntity n=new LineEntity(s(x.start,factor,pivot),s(x.end,factor,pivot)); n.setLayer(e.getLayer()); return n;
        }
        if(e instanceof CircleEntity){
            CircleEntity x=(CircleEntity)e;
            CircleEntity n=new CircleEntity(s(x.center,factor,pivot),x.radius*factor); n.setLayer(e.getLayer()); return n;
        }
        if(e instanceof ArcEntity){
            ArcEntity x=(ArcEntity)e;
            ArcEntity n=new ArcEntity(s(x.center,factor,pivot),x.radius*factor,x.startAngleDeg,x.endAngleDeg); n.setLayer(e.getLayer()); return n;
        }
        if(e instanceof TextEntity){
            TextEntity x=(TextEntity)e;
            TextEntity n=new TextEntity(x.getType(),s(x.position,factor,pivot),x.text,x.height*factor,x.rotationDeg); n.setLayer(e.getLayer()); return n;
        }
        if(e instanceof InsertEntity){
            InsertEntity x=(InsertEntity)e;
            InsertEntity n=new InsertEntity(x.blockName,s(x.position,factor,pivot),x.scaleX*factor,x.scaleY*factor,x.rotationDeg); n.setLayer(e.getLayer()); return n;
        }
        return e;
    }

    private Point2D p(Point2D p,double dx,double dy){ return new Point2D(p.x+dx,p.y+dy); }
    private Point2D r(Point2D p,double a,Point2D c){
        double rad=Math.toRadians(a),x=p.x-c.x,y=p.y-c.y;
        return new Point2D(c.x+x*Math.cos(rad)-y*Math.sin(rad),c.y+x*Math.sin(rad)+y*Math.cos(rad));
    }
    private Point2D s(Point2D p,double f,Point2D c){ return new Point2D(c.x+(p.x-c.x)*f,c.y+(p.y-c.y)*f); }
}
