package com.dao.autocard.cad.history;

import com.dao.autocard.cad.model.CadEntity;

public final class ChangeLayerCommand implements EditCommand {
    private final CadEntity entity;
    private final String before;
    private final String after;

    public ChangeLayerCommand(CadEntity entity, String after) {
        this.entity = entity;
        this.before = entity == null ? "0" : entity.getLayer();
        this.after = after == null || after.trim().isEmpty() ? "0" : after.trim();
    }

    @Override public void execute() { if (entity != null) entity.setLayer(after); }
    @Override public void undo() { if (entity != null) entity.setLayer(before); }
    @Override public String getLabel() { return "Đổi layer"; }
}
