package com.dao.autocard.cad.text;

public interface TranslationProvider {
    interface Callback {
        void onSuccess(String translated);
        void onFailure(Throwable error);
    }

    void translate(String text, String sourceLanguage, String targetLanguage, Callback callback);
}
