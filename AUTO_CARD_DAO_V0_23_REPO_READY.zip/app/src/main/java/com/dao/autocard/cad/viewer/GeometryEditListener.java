package com.dao.autocard.cad.viewer;

import com.dao.autocard.cad.model.CadEntity;

public interface GeometryEditListener {
    void onReplaceRequested(CadEntity before, CadEntity after, String label);
}
