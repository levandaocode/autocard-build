package com.dao.autocard.cad.measure;

import com.dao.autocard.cad.model.*;
import java.util.*;

public final class MeasurementOverlay {
    private final List<MeasurementOverlayItem> items = new ArrayList<>();

    public void rebuild(DrawingDocument document) {
        items.clear();
        if (document == null) return;

        for (CadEntity e : document.getEntities()) {
            if (e instanceof LineEntity) {
                LineEntity x = (LineEntity)e;
                Point2D mid = new Point2D((x.start.x+x.end.x)/2.0,(x.start.y+x.end.y)/2.0);
                items.add(new MeasurementOverlayItem(mid,
                        String.format(Locale.US,"L=%.3f %s",x.length(),document.getUnit())));
            } else if (e instanceof CircleEntity) {
                CircleEntity x=(CircleEntity)e;
                items.add(new MeasurementOverlayItem(x.center,
                        String.format(Locale.US,"R=%.3f  Ø=%.3f",x.radius,x.radius*2.0)));
            } else if (e instanceof ArcEntity) {
                ArcEntity x=(ArcEntity)e;
                items.add(new MeasurementOverlayItem(x.center,
                        String.format(Locale.US,"R=%.3f  α=%.2f°",x.radius,x.sweepDeg())));
            } else if (e instanceof PolylineEntity) {
                PolylineEntity x=(PolylineEntity)e;
                if (!x.getPoints().isEmpty()) {
                    items.add(new MeasurementOverlayItem(x.getPoints().get(0),
                            String.format(Locale.US,"P=%.3f",x.length())));
                }
            } else if (e instanceof EllipseEntity) {
                EllipseEntity x=(EllipseEntity)e;
                items.add(new MeasurementOverlayItem(x.center,
                        String.format(Locale.US,"a=%.3f  b=%.3f",x.majorRadius(),x.minorRadius())));
            }
        }
    }

    public List<MeasurementOverlayItem> getItems() {
        return Collections.unmodifiableList(items);
    }
}
