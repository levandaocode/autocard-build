package com.dao.autocard.cad.text;

import com.dao.autocard.cad.model.*;
import java.util.*;

public final class BatchTranslationEngine {
    private final TextTranslationEngine engine;
    private final MTextCleaner cleaner = new MTextCleaner();

    public BatchTranslationEngine(TextTranslationEngine engine) {
        this.engine = engine;
    }

    public interface ProgressCallback {
        void onProgress(int completed, int total, TextEntity entity, TranslatedText result);
        void onFinished(int total);
    }

    public void translateAll(DrawingDocument document,
                             TranslationStore store,
                             ProgressCallback callback) {
        if (document == null) {
            if (callback != null) callback.onFinished(0);
            return;
        }

        List<TextEntity> texts = new ArrayList<>();
        for (CadEntity e : document.getEntities()) {
            if (e instanceof TextEntity) texts.add((TextEntity)e);
        }

        if (texts.isEmpty()) {
            if (callback != null) callback.onFinished(0);
            return;
        }

        translateNext(texts, 0, store, callback);
    }

    private void translateNext(List<TextEntity> texts,
                               int index,
                               TranslationStore store,
                               ProgressCallback callback) {
        if (index >= texts.size()) {
            if (callback != null) callback.onFinished(texts.size());
            return;
        }

        TextEntity originalEntity = texts.get(index);

        // Use a cleaned copy for translation, preserving source entity unchanged.
        TextEntity cleaned = new TextEntity(
                originalEntity.getType(),
                originalEntity.position,
                cleaner.clean(originalEntity.text),
                originalEntity.height,
                originalEntity.rotationDeg
        );
        cleaned.setLayer(originalEntity.getLayer());

        engine.translate(cleaned, result -> {
            store.put(originalEntity, result);
            if (callback != null) {
                callback.onProgress(index + 1, texts.size(), originalEntity, result);
            }
            translateNext(texts, index + 1, store, callback);
        });
    }
}
