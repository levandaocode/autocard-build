package com.dao.autocard.cad.measure;

import com.dao.autocard.cad.model.*;
import java.util.ArrayList;
import java.util.List;

public class MeasureEngine {
    public List<MeasurementResult> collectAll(DrawingDocument document) {
        List<MeasurementResult> out = new ArrayList<>();
        if (document == null) return out;

        for (CadEntity entity : document.getEntities()) {
            if (entity instanceof LineEntity) {
                LineEntity line = (LineEntity) entity;
                out.add(new MeasurementResult("Chiều dài LINE", line.length(), document.getUnit()));
            } else if (entity instanceof CircleEntity) {
                CircleEntity c = (CircleEntity) entity;
                out.add(new MeasurementResult("Bán kính", c.radius, document.getUnit()));
                out.add(new MeasurementResult("Đường kính", c.radius * 2, document.getUnit()));
                out.add(new MeasurementResult("Chu vi", 2 * Math.PI * c.radius, document.getUnit()));
                out.add(new MeasurementResult("Diện tích", Math.PI * c.radius * c.radius, document.getUnit() + "²"));
            } else if (entity instanceof ArcEntity) {
                ArcEntity a = (ArcEntity) entity;
                out.add(new MeasurementResult("Bán kính cung", a.radius, document.getUnit()));
                out.add(new MeasurementResult("Góc cung", a.sweepDeg(), "°"));
                out.add(new MeasurementResult("Chiều dài cung", a.arcLength(), document.getUnit()));
            } else if (entity instanceof PolylineEntity) {
                PolylineEntity p = (PolylineEntity) entity;
                out.add(new MeasurementResult("Chiều dài Polyline", p.length(), document.getUnit()));
                if (p.isClosed()) {
                    out.add(new MeasurementResult("Diện tích Polyline", p.area(), document.getUnit() + "²"));
                }
            } else if (entity instanceof EllipseEntity) {
                EllipseEntity e = (EllipseEntity) entity;
                out.add(new MeasurementResult("Bán trục lớn", e.majorRadius(), document.getUnit()));
                out.add(new MeasurementResult("Bán trục nhỏ", e.minorRadius(), document.getUnit()));
                out.add(new MeasurementResult("Diện tích Ellipse", Math.PI * e.majorRadius() * e.minorRadius(), document.getUnit() + "²"));
            }
        }
        return out;
    }
}
