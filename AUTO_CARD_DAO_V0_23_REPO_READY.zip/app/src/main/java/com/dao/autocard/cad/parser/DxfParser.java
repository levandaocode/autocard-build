package com.dao.autocard.cad.parser;

import com.dao.autocard.cad.model.*;
import com.dao.autocard.cad.text.MTextCleaner;

import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.*;

public final class DxfParser {
    private ParseDiagnostics diagnostics = new ParseDiagnostics();

    public ParseDiagnostics getDiagnostics() { return diagnostics; }


    public DrawingDocument parse(File file) throws IOException {
        try (InputStream in = new FileInputStream(file)) { return parse(in); }
    }

    public DrawingDocument parse(InputStream in) throws IOException {
        diagnostics = new ParseDiagnostics();
        List<DxfPair> pairs = readPairs(in);
        DrawingDocument doc = new DrawingDocument();

        parseBlocks(pairs, doc);
        parseEntities(pairs, doc);
        return doc;
    }

    private void parseEntities(List<DxfPair> pairs, DrawingDocument doc) {
        boolean inEntities=false;
        for(int i=0;i<pairs.size();) {
            DxfPair p=pairs.get(i);
            if(p.code==0 && "SECTION".equalsIgnoreCase(p.value)) {
                if(i+1<pairs.size() && pairs.get(i+1).code==2)
                    inEntities="ENTITIES".equalsIgnoreCase(pairs.get(i+1).value);
                i++; continue;
            }
            if(p.code==0 && "ENDSEC".equalsIgnoreCase(p.value)) {
                inEntities=false; i++; continue;
            }
            if(!inEntities || p.code!=0) { i++; continue; }

            String type=p.value.trim().toUpperCase(Locale.ROOT);

            if("POLYLINE".equals(type)) {
                ParseResult r=parseClassicPolyline(pairs,i);
                if(r.entity!=null) doc.add(r.entity);
                i=r.nextIndex;
                continue;
            }

            int end=i+1;
            while(end<pairs.size() && pairs.get(end).code!=0) end++;
            CadEntity e=parseEntity(type,pairs.subList(i,end));
            if(e!=null) doc.add(e);
            i=end;
        }
    }

    private void parseBlocks(List<DxfPair> pairs, DrawingDocument doc) {
        boolean inBlocks=false;
        for(int i=0;i<pairs.size();) {
            DxfPair p=pairs.get(i);
            if(p.code==0 && "SECTION".equalsIgnoreCase(p.value)) {
                if(i+1<pairs.size() && pairs.get(i+1).code==2)
                    inBlocks="BLOCKS".equalsIgnoreCase(pairs.get(i+1).value);
                i++; continue;
            }
            if(p.code==0 && "ENDSEC".equalsIgnoreCase(p.value)) { inBlocks=false; i++; continue; }
            if(!inBlocks || !(p.code==0 && "BLOCK".equalsIgnoreCase(p.value))) { i++; continue; }

            int headerEnd=i+1;
            while(headerEnd<pairs.size() && pairs.get(headerEnd).code!=0) headerEnd++;
            List<DxfPair> header=pairs.subList(i,headerEnd);
            String name=text(header,2,"");
            Point2D base=new Point2D(value(header,10,0),value(header,20,0));
            BlockDefinition block=new BlockDefinition(name,base);

            i=headerEnd;
            while(i<pairs.size()) {
                DxfPair q=pairs.get(i);
                if(q.code==0 && "ENDBLK".equalsIgnoreCase(q.value)) { i++; break; }
                if(q.code==0) {
                    String type=q.value.trim().toUpperCase(Locale.ROOT);
                    int end=i+1;
                    while(end<pairs.size() && pairs.get(end).code!=0) end++;
                    CadEntity e=parseEntity(type,pairs.subList(i,end));
                    if(e!=null) block.add(e);
                    i=end;
                } else i++;
            }
            doc.addBlock(block);
        }
    }

    private ParseResult parseClassicPolyline(List<DxfPair> pairs,int start) {
        int headerEnd=start+1;
        while(headerEnd<pairs.size() && pairs.get(headerEnd).code!=0) headerEnd++;
        List<DxfPair> header=pairs.subList(start,headerEnd);

        PolylineEntity poly=new PolylineEntity();
        poly.setLayer(text(header,8,"0"));
        poly.setClosed((intValue(header,70,0)&1)!=0);

        int i=headerEnd;
        while(i<pairs.size()) {
            DxfPair p=pairs.get(i);
            if(p.code==0 && "SEQEND".equalsIgnoreCase(p.value)) {
                i++;
                break;
            }
            if(p.code==0 && "VERTEX".equalsIgnoreCase(p.value)) {
                int end=i+1;
                while(end<pairs.size() && pairs.get(end).code!=0) end++;
                List<DxfPair> v=pairs.subList(i,end);
                poly.addPoint(new Point2D(value(v,10,0),value(v,20,0)));
                i=end;
            } else {
                i++;
            }
        }
        return new ParseResult(poly,i);
    }

    private CadEntity parseEntity(String type,List<DxfPair> e) {
        switch(type) {
            case "LINE": return parseLine(e);
            case "CIRCLE": return parseCircle(e);
            case "ARC": return parseArc(e);
            case "LWPOLYLINE": return parseLwPolyline(e);
            case "TEXT": return parseText(e,EntityType.TEXT);
            case "MTEXT": return parseText(e,EntityType.MTEXT);
            case "ELLIPSE": return parseEllipse(e);
            case "SPLINE": return parseSpline(e);
            case "INSERT": return parseInsert(e);
            case "DIMENSION": return parseDimension(e);
            case "HATCH": return parseHatch(e);
            case "LEADER": return parseLeader(e, false);
            case "MLEADER": return parseLeader(e, true);
            default: diagnostics.recordUnsupported(type); return null;
        }
    }

    private LineEntity parseLine(List<DxfPair> e){
        LineEntity out=new LineEntity(new Point2D(value(e,10,0),value(e,20,0)),
                                      new Point2D(value(e,11,0),value(e,21,0)));
        out.setLayer(text(e,8,"0")); return out;
    }

    private CircleEntity parseCircle(List<DxfPair> e){
        CircleEntity out=new CircleEntity(new Point2D(value(e,10,0),value(e,20,0)),value(e,40,0));
        out.setLayer(text(e,8,"0")); return out;
    }

    private ArcEntity parseArc(List<DxfPair> e){
        ArcEntity out=new ArcEntity(new Point2D(value(e,10,0),value(e,20,0)),
                                    value(e,40,0),value(e,50,0),value(e,51,0));
        out.setLayer(text(e,8,"0")); return out;
    }

    private PolylineEntity parseLwPolyline(List<DxfPair> e){
        PolylineEntity out=new PolylineEntity();
        out.setLayer(text(e,8,"0"));
        out.setClosed((intValue(e,70,0)&1)!=0);
        Double x=null;
        for(DxfPair p:e){
            if(p.code==10) x=p.asDouble(0);
            else if(p.code==20 && x!=null){
                out.addPoint(new Point2D(x,p.asDouble(0))); x=null;
            }
        }
        return out;
    }

    private TextEntity parseText(List<DxfPair> e,EntityType type){
        StringBuilder sb=new StringBuilder();
        for(DxfPair p:e){
            if(p.code==1 || p.code==3){
                if(sb.length()>0) sb.append("\n");
                sb.append(p.value);
            }
        }
        String parsedText = sb.toString();
        if (type == EntityType.MTEXT) parsedText = new MTextCleaner().clean(parsedText);
        TextEntity out=new TextEntity(type,new Point2D(value(e,10,0),value(e,20,0)),
                parsedText,value(e,40,2.5),value(e,50,0));
        out.setLayer(text(e,8,"0")); return out;
    }

    private EllipseEntity parseEllipse(List<DxfPair> e){
        EllipseEntity out=new EllipseEntity(
            new Point2D(value(e,10,0),value(e,20,0)),
            new Point2D(value(e,11,1),value(e,21,0)),
            value(e,40,1),
            value(e,41,0),
            value(e,42,Math.PI*2)
        );
        out.setLayer(text(e,8,"0")); return out;
    }

    private SplineEntity parseSpline(List<DxfPair> e){
        SplineEntity out=new SplineEntity();
        out.setLayer(text(e,8,"0"));
        Double x=null;
        for(DxfPair p:e){
            if(p.code==10) x=p.asDouble(0);
            else if(p.code==20 && x!=null){
                out.addControlPoint(new Point2D(x,p.asDouble(0))); x=null;
            }
        }
        x=null;
        for(DxfPair p:e){
            if(p.code==11) x=p.asDouble(0);
            else if(p.code==21 && x!=null){
                out.addFitPoint(new Point2D(x,p.asDouble(0))); x=null;
            }
        }
        return out;
    }

    private InsertEntity parseInsert(List<DxfPair> e){
        InsertEntity out=new InsertEntity(text(e,2,""),
                new Point2D(value(e,10,0),value(e,20,0)),
                value(e,41,1),value(e,42,1),value(e,50,0));
        out.setLayer(text(e,8,"0")); return out;
    }


    private DimensionEntity parseDimension(List<DxfPair> e){
        DimensionEntity out=new DimensionEntity(
                new Point2D(value(e,10,0),value(e,20,0)),
                new Point2D(value(e,11,0),value(e,21,0)),
                text(e,1,""),
                value(e,42,0)
        );
        out.setLayer(text(e,8,"0"));
        return out;
    }

    private HatchEntity parseHatch(List<DxfPair> e){
        HatchEntity out=new HatchEntity();
        out.setLayer(text(e,8,"0"));
        java.util.List<Point2D> current=new java.util.ArrayList<>();
        Double x=null;
        for(DxfPair p:e){
            if(p.code==10) x=p.asDouble(0);
            else if(p.code==20 && x!=null){
                current.add(new Point2D(x,p.asDouble(0)));
                x=null;
            } else if(p.code==92 && !current.isEmpty()){
                out.addLoop(current);
                current=new java.util.ArrayList<>();
            }
        }
        if(!current.isEmpty()) out.addLoop(current);
        return out;
    }

    private LeaderEntity parseLeader(List<DxfPair> e, boolean multi){
        LeaderEntity out=new LeaderEntity(multi);
        out.setLayer(text(e,8,"0"));
        Double x=null;
        for(DxfPair p:e){
            if(p.code==10) x=p.asDouble(0);
            else if(p.code==20 && x!=null){
                out.addPoint(new Point2D(x,p.asDouble(0)));
                x=null;
            }
        }
        return out;
    }

    private List<DxfPair> readPairs(InputStream in)throws IOException{
        BufferedReader br=new BufferedReader(new InputStreamReader(in,StandardCharsets.UTF_8));
        List<DxfPair> out=new ArrayList<>();
        String c;
        while((c=br.readLine())!=null){
            String v=br.readLine(); if(v==null) break;
            try{ out.add(new DxfPair(Integer.parseInt(c.trim()),v)); }
            catch(NumberFormatException ignored){}
        }
        return out;
    }

    private double value(List<DxfPair> e,int code,double fallback){
        for(DxfPair p:e) if(p.code==code) return p.asDouble(fallback);
        return fallback;
    }

    private int intValue(List<DxfPair> e,int code,int fallback){
        for(DxfPair p:e) if(p.code==code) return p.asInt(fallback);
        return fallback;
    }

    private String text(List<DxfPair> e,int code,String fallback){
        for(DxfPair p:e) if(p.code==code) return p.value;
        return fallback;
    }

    private static final class ParseResult {
        final CadEntity entity; final int nextIndex;
        ParseResult(CadEntity entity,int nextIndex){this.entity=entity;this.nextIndex=nextIndex;}
    }
}
