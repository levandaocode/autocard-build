package com.dao.autocard.cad.model;

public final class ArcEntity extends CadEntity {
    public final Point2D center;
    public final double radius;
    public final double startAngleDeg;
    public final double endAngleDeg;

    public ArcEntity(Point2D center, double radius, double startAngleDeg, double endAngleDeg) {
        super(EntityType.ARC);
        this.center = center;
        this.radius = radius;
        this.startAngleDeg = startAngleDeg;
        this.endAngleDeg = endAngleDeg;
    }

    public double sweepDeg() {
        double s = endAngleDeg - startAngleDeg;
        while (s < 0) s += 360.0;
        while (s >= 360.0) s -= 360.0;
        return s;
    }

    public double arcLength() {
        return Math.toRadians(sweepDeg()) * radius;
    }
}
