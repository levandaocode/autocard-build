package com.dao.autocard.cad.writer;

import com.dao.autocard.cad.model.*;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.*;

public final class DxfWriter {

    public File write(DrawingDocument doc, File file) throws IOException {
        try (Writer w = new OutputStreamWriter(new FileOutputStream(file), StandardCharsets.UTF_8)) {
            pair(w,0,"SECTION");
            pair(w,2,"ENTITIES");

            for (CadEntity e : doc.getEntities()) {
                if (e instanceof LineEntity) writeLine(w,(LineEntity)e);
                else if (e instanceof CircleEntity) writeCircle(w,(CircleEntity)e);
                else if (e instanceof ArcEntity) writeArc(w,(ArcEntity)e);
                else if (e instanceof PolylineEntity) writePolyline(w,(PolylineEntity)e);
                else if (e instanceof TextEntity) writeText(w,(TextEntity)e);
                else if (e instanceof EllipseEntity) writeEllipse(w,(EllipseEntity)e);
                else if (e instanceof InsertEntity) writeInsert(w,(InsertEntity)e);
                else if (e instanceof DimensionEntity) writeDimension(w,(DimensionEntity)e);
            }

            pair(w,0,"ENDSEC");
            pair(w,0,"EOF");
        }
        return file;
    }

    private void base(Writer w, CadEntity e) throws IOException {
        pair(w,8,e.getLayer());
    }

    private void writeLine(Writer w, LineEntity e)throws IOException{
        pair(w,0,"LINE"); base(w,e);
        pair(w,10,e.start.x); pair(w,20,e.start.y);
        pair(w,11,e.end.x); pair(w,21,e.end.y);
    }

    private void writeCircle(Writer w, CircleEntity e)throws IOException{
        pair(w,0,"CIRCLE"); base(w,e);
        pair(w,10,e.center.x); pair(w,20,e.center.y); pair(w,40,e.radius);
    }

    private void writeArc(Writer w, ArcEntity e)throws IOException{
        pair(w,0,"ARC"); base(w,e);
        pair(w,10,e.center.x); pair(w,20,e.center.y); pair(w,40,e.radius);
        pair(w,50,e.startAngleDeg); pair(w,51,e.endAngleDeg);
    }

    private void writePolyline(Writer w, PolylineEntity e)throws IOException{
        pair(w,0,"LWPOLYLINE"); base(w,e);
        pair(w,90,e.getPoints().size()); pair(w,70,e.isClosed()?1:0);
        for(Point2D p:e.getPoints()){ pair(w,10,p.x); pair(w,20,p.y); }
    }

    private void writeText(Writer w, TextEntity e)throws IOException{
        pair(w,0,e.getType()==EntityType.MTEXT?"MTEXT":"TEXT"); base(w,e);
        pair(w,10,e.position.x); pair(w,20,e.position.y);
        pair(w,40,e.height); pair(w,50,e.rotationDeg); pair(w,1,e.text);
    }

    private void writeEllipse(Writer w, EllipseEntity e)throws IOException{
        pair(w,0,"ELLIPSE"); base(w,e);
        pair(w,10,e.center.x); pair(w,20,e.center.y);
        pair(w,11,e.majorAxisVector.x); pair(w,21,e.majorAxisVector.y);
        pair(w,40,e.ratio); pair(w,41,e.startParam); pair(w,42,e.endParam);
    }

    private void writeInsert(Writer w, InsertEntity e)throws IOException{
        pair(w,0,"INSERT"); base(w,e); pair(w,2,e.blockName);
        pair(w,10,e.position.x); pair(w,20,e.position.y);
        pair(w,41,e.scaleX); pair(w,42,e.scaleY); pair(w,50,e.rotationDeg);
    }

    private void writeDimension(Writer w, DimensionEntity e)throws IOException{
        pair(w,0,"DIMENSION"); base(w,e);
        pair(w,10,e.definitionPoint.x); pair(w,20,e.definitionPoint.y);
        pair(w,11,e.textPoint.x); pair(w,21,e.textPoint.y);
        pair(w,1,e.text); pair(w,42,e.measurement);
    }

    private void pair(Writer w,int code,Object value)throws IOException{
        w.write(Integer.toString(code)); w.write("\n");
        w.write(String.valueOf(value)); w.write("\n");
    }
}
