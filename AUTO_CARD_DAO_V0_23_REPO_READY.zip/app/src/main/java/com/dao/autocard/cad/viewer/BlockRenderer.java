package com.dao.autocard.cad.viewer;

import android.graphics.*;
import com.dao.autocard.cad.model.*;
import java.util.*;

public final class BlockRenderer {
    private static final int MAX_DEPTH = 16;

    public interface WorldToScreen {
        float sx(double x);
        float sy(double y);
        float scale();
    }

    public void drawInsert(Canvas canvas, DrawingDocument document,
                           InsertEntity insert, Paint paint, WorldToScreen t) {
        drawInsert(canvas, document, insert, paint, t, new HashSet<String>(), 0);
    }

    private void drawInsert(Canvas canvas, DrawingDocument document,
                            InsertEntity insert, Paint paint, WorldToScreen t,
                            Set<String> stack, int depth) {
        if (document == null || insert == null || depth > MAX_DEPTH) return;
        if (stack.contains(insert.blockName)) return;

        BlockDefinition block = document.getBlock(insert.blockName);
        if (block == null) return;

        stack.add(insert.blockName);
        for (CadEntity e : block.getEntities()) {
            if (e instanceof InsertEntity) {
                InsertEntity child = compose((InsertEntity)e, block.basePoint, insert);
                drawInsert(canvas, document, child, paint, t, stack, depth + 1);
            } else {
                drawTransformedEntity(canvas, e, block.basePoint, insert, paint, t);
            }
        }
        stack.remove(insert.blockName);
    }

    private InsertEntity compose(InsertEntity child, Point2D parentBase, InsertEntity parent) {
        Point2D pos = transform(child.position, parentBase, parent);
        InsertEntity out = new InsertEntity(
                child.blockName,
                pos,
                child.scaleX * parent.scaleX,
                child.scaleY * parent.scaleY,
                child.rotationDeg + parent.rotationDeg
        );
        out.setLayer(child.getLayer());
        return out;
    }

    private Point2D transform(Point2D p, Point2D base, InsertEntity ins) {
        double x=(p.x-base.x)*ins.scaleX;
        double y=(p.y-base.y)*ins.scaleY;
        double a=Math.toRadians(ins.rotationDeg);
        return new Point2D(
                ins.position.x + x*Math.cos(a)-y*Math.sin(a),
                ins.position.y + x*Math.sin(a)+y*Math.cos(a)
        );
    }

    private void drawTransformedEntity(Canvas canvas, CadEntity entity,
                                       Point2D base, InsertEntity ins,
                                       Paint paint, WorldToScreen t) {
        if (entity instanceof LineEntity) {
            LineEntity e=(LineEntity)entity;
            Point2D a=transform(e.start,base,ins), b=transform(e.end,base,ins);
            canvas.drawLine(t.sx(a.x),t.sy(a.y),t.sx(b.x),t.sy(b.y),paint);
        } else if (entity instanceof CircleEntity) {
            CircleEntity e=(CircleEntity)entity;
            Point2D c=transform(e.center,base,ins);
            double s=(Math.abs(ins.scaleX)+Math.abs(ins.scaleY))*0.5;
            canvas.drawCircle(t.sx(c.x),t.sy(c.y),(float)(e.radius*s*t.scale()),paint);
        } else if (entity instanceof PolylineEntity) {
            PolylineEntity e=(PolylineEntity)entity;
            if(e.getPoints().isEmpty()) return;
            Path path=new Path();
            Point2D p0=transform(e.getPoints().get(0),base,ins);
            path.moveTo(t.sx(p0.x),t.sy(p0.y));
            for(int i=1;i<e.getPoints().size();i++){
                Point2D q=transform(e.getPoints().get(i),base,ins);
                path.lineTo(t.sx(q.x),t.sy(q.y));
            }
            if(e.isClosed()) path.close();
            canvas.drawPath(path,paint);
        } else if (entity instanceof TextEntity) {
            TextEntity e=(TextEntity)entity;
            Point2D p=transform(e.position,base,ins);
            canvas.drawText(e.text,t.sx(p.x),t.sy(p.y),paint);
        }
    }
}
