package com.dao.autocard.cad.model;

public final class Point2D {
    public final double x;
    public final double y;

    public Point2D(double x, double y) {
        this.x = x;
        this.y = y;
    }

    public double distanceTo(Point2D other) {
        double dx = other.x - x;
        double dy = other.y - y;
        return Math.hypot(dx, dy);
    }
}
