package com.dao.autocard.cad.model;

public enum EntityType {
    LINE, POLYLINE, CIRCLE, ARC, ELLIPSE, SPLINE, TEXT, MTEXT, DIMENSION, HATCH, LEADER, MLEADER, BLOCK, INSERT, UNKNOWN
}
