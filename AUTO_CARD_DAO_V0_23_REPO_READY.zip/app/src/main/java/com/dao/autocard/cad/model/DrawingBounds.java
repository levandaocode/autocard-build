package com.dao.autocard.cad.model;

public final class DrawingBounds {
    public double minX = Double.POSITIVE_INFINITY;
    public double minY = Double.POSITIVE_INFINITY;
    public double maxX = Double.NEGATIVE_INFINITY;
    public double maxY = Double.NEGATIVE_INFINITY;

    public void include(double x, double y) {
        if (x < minX) minX = x;
        if (y < minY) minY = y;
        if (x > maxX) maxX = x;
        if (y > maxY) maxY = y;
    }

    public boolean isValid() {
        return minX != Double.POSITIVE_INFINITY &&
               minY != Double.POSITIVE_INFINITY &&
               maxX != Double.NEGATIVE_INFINITY &&
               maxY != Double.NEGATIVE_INFINITY;
    }

    public double width() { return isValid() ? maxX - minX : 0; }
    public double height() { return isValid() ? maxY - minY : 0; }
    public double centerX() { return (minX + maxX) * 0.5; }
    public double centerY() { return (minY + maxY) * 0.5; }
}
