package com.dao.autocard.cad.parser;

import java.util.*;

public final class ParseDiagnostics {
    private final Map<String,Integer> unsupported = new LinkedHashMap<>();

    public void recordUnsupported(String type) {
        if (type == null || type.trim().isEmpty()) return;
        Integer n = unsupported.get(type);
        unsupported.put(type, n == null ? 1 : n + 1);
    }

    public Map<String,Integer> getUnsupported() {
        return Collections.unmodifiableMap(unsupported);
    }

    public boolean hasUnsupported() { return !unsupported.isEmpty(); }

    public String summary() {
        if (unsupported.isEmpty()) return "Không có entity chưa hỗ trợ";
        StringBuilder sb=new StringBuilder();
        for (Map.Entry<String,Integer> e:unsupported.entrySet()) {
            if (sb.length()>0) sb.append("\n");
            sb.append(e.getKey()).append(": ").append(e.getValue());
        }
        return sb.toString();
    }
}
