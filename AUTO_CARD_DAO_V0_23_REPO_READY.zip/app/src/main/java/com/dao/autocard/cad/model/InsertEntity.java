package com.dao.autocard.cad.model;

public final class InsertEntity extends CadEntity {
    public final String blockName;
    public final Point2D position;
    public final double scaleX;
    public final double scaleY;
    public final double rotationDeg;

    public InsertEntity(String blockName, Point2D position,
                        double scaleX, double scaleY, double rotationDeg) {
        super(EntityType.INSERT);
        this.blockName = blockName == null ? "" : blockName;
        this.position = position;
        this.scaleX = scaleX;
        this.scaleY = scaleY;
        this.rotationDeg = rotationDeg;
    }
}
