package com.dao.autocard.cad.text;

public enum TextDisplayMode {
    ORIGINAL,
    BILINGUAL,
    TRANSLATED
}
