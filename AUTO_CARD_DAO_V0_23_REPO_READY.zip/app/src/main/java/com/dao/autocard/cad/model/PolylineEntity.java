package com.dao.autocard.cad.model;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public final class PolylineEntity extends CadEntity {
    private final List<Point2D> points = new ArrayList<>();
    private boolean closed;

    public PolylineEntity() {
        super(EntityType.POLYLINE);
    }

    public void addPoint(Point2D p) {
        if (p != null) points.add(p);
    }

    public List<Point2D> getPoints() {
        return Collections.unmodifiableList(points);
    }

    public boolean isClosed() { return closed; }
    public void setClosed(boolean closed) { this.closed = closed; }

    public double length() {
        double total = 0;
        for (int i = 1; i < points.size(); i++) {
            total += points.get(i - 1).distanceTo(points.get(i));
        }
        if (closed && points.size() > 2) {
            total += points.get(points.size() - 1).distanceTo(points.get(0));
        }
        return total;
    }

    public double area() {
        if (!closed || points.size() < 3) return 0;
        double sum = 0;
        for (int i = 0; i < points.size(); i++) {
            Point2D a = points.get(i);
            Point2D b = points.get((i + 1) % points.size());
            sum += (a.x * b.y) - (b.x * a.y);
        }
        return Math.abs(sum) * 0.5;
    }
}
