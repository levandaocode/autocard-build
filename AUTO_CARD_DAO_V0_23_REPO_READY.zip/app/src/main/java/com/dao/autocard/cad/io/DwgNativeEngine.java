
package com.dao.autocard.cad.io;

import com.dao.autocard.cad.model.DrawingDocument;
import java.io.*;
import java.util.*;

public final class DwgNativeEngine implements DwgEngine {

    @Override
    public boolean supportsVersion(String versionCode) {
        return versionCode != null && versionCode.startsWith("AC10");
    }

    @Override
    public DrawingDocument read(InputStream in) throws Exception {
        byte[] bytes = readAll(in);

        if (!DwgNativeBridge.isLoaded()) {
            throw new IllegalStateException("Thư viện DWG native chưa được nạp");
        }

        if (!DwgNativeBridge.nativeSupports(bytes)) {
            throw new IOException("File không phải DWG được native engine hỗ trợ");
        }

        // JNI contract is in place. Production decoder will return full entity
        // data; for now this intentionally does not pretend decoding is complete.
        String summary = DwgNativeBridge.nativeParseSummary(bytes);
        throw new UnsupportedOperationException(
                "DWG native bridge hoạt động nhưng decoder đầy đủ chưa được cấy. " + summary);
    }

    private byte[] readAll(InputStream in) throws IOException {
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        byte[] buf = new byte[16384];
        int n;
        while ((n = in.read(buf)) != -1) out.write(buf,0,n);
        return out.toByteArray();
    }
}
