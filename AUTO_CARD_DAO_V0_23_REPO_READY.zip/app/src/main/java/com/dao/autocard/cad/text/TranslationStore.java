package com.dao.autocard.cad.text;

import com.dao.autocard.cad.model.TextEntity;
import java.util.*;

public final class TranslationStore {
    private final Map<TextEntity, TranslatedText> map = new IdentityHashMap<>();

    public void put(TextEntity entity, TranslatedText result) {
        if (entity != null && result != null) map.put(entity, result);
    }

    public TranslatedText get(TextEntity entity) {
        return map.get(entity);
    }

    public void clear() {
        map.clear();
    }

    public int size() {
        return map.size();
    }
}
