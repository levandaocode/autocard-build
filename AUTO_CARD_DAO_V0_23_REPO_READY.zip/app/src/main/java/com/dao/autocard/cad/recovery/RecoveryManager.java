package com.dao.autocard.cad.recovery;

import android.content.Context;
import com.dao.autocard.cad.model.DrawingDocument;
import com.dao.autocard.cad.writer.DxfWriter;
import java.io.*;

public final class RecoveryManager {
    private static final String NAME="autosave_recovery.dxf";

    public File autosave(Context context, DrawingDocument doc) throws IOException {
        File dir=new File(context.getFilesDir(),"recovery");
        if(!dir.exists()) dir.mkdirs();
        File file=new File(dir,NAME);
        return new DxfWriter().write(doc,file);
    }

    public File getRecoveryFile(Context context){
        File file=new File(new File(context.getFilesDir(),"recovery"),NAME);
        return file.exists()?file:null;
    }

    public void clear(Context context){
        File f=getRecoveryFile(context);
        if(f!=null) f.delete();
    }
}
