package com.dao.autocard.cad.text;

public final class TranslatedText {
    public final String original;
    public final String translated;
    public final String sourceLanguage;
    public final String targetLanguage;

    public TranslatedText(String original, String translated,
                          String sourceLanguage, String targetLanguage) {
        this.original = original;
        this.translated = translated;
        this.sourceLanguage = sourceLanguage;
        this.targetLanguage = targetLanguage;
    }
}
