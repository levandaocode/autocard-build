package com.dao.autocard.cad.io;

import java.io.*;
import java.nio.charset.StandardCharsets;

public final class CadFileDetector {

    public CadFileType detect(InputStream input) throws IOException {
        if (input == null) return CadFileType.UNKNOWN;

        BufferedInputStream in = input instanceof BufferedInputStream
                ? (BufferedInputStream)input
                : new BufferedInputStream(input);

        in.mark(64);
        byte[] head = new byte[32];
        int n = in.read(head);
        in.reset();

        if (n >= 6) {
            String six = new String(head, 0, 6, StandardCharsets.US_ASCII);
            if (six.startsWith("AC10")) return CadFileType.DWG;
        }

        String ascii = n > 0
                ? new String(head, 0, n, StandardCharsets.US_ASCII)
                : "";
        if (ascii.contains("SECTION") || ascii.trim().startsWith("0")) {
            return CadFileType.DXF;
        }

        return CadFileType.UNKNOWN;
    }

    public String readDwgVersion(InputStream input) throws IOException {
        BufferedInputStream in = input instanceof BufferedInputStream
                ? (BufferedInputStream)input
                : new BufferedInputStream(input);
        in.mark(16);
        byte[] head = new byte[6];
        int n = in.read(head);
        in.reset();
        if (n < 6) return "";
        return new String(head, StandardCharsets.US_ASCII);
    }

    public String describeDwgVersion(String code) {
        if ("AC1012".equals(code)) return "AutoCAD R13/R14";
        if ("AC1015".equals(code)) return "AutoCAD 2000/2000i/2002";
        if ("AC1018".equals(code)) return "AutoCAD 2004/2005/2006";
        if ("AC1021".equals(code)) return "AutoCAD 2007/2008/2009";
        if ("AC1024".equals(code)) return "AutoCAD 2010/2011/2012";
        if ("AC1027".equals(code)) return "AutoCAD 2013-2017";
        if ("AC1032".equals(code)) return "AutoCAD 2018+";
        return code == null || code.isEmpty() ? "Không xác định" : code;
    }
}
