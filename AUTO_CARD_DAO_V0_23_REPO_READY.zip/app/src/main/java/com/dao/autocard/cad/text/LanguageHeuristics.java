package com.dao.autocard.cad.text;

public final class LanguageHeuristics {

    public String detect(String text) {
        if (text == null || text.trim().isEmpty()) return "und";

        boolean cjk=false, kana=false, hangul=false, cyrillic=false, arabic=false, thai=false, devanagari=false;
        boolean latin=false, vietnamese=false;

        for (int i=0;i<text.length();i++) {
            char c=text.charAt(i);
            Character.UnicodeBlock b=Character.UnicodeBlock.of(c);

            if (b==Character.UnicodeBlock.CJK_UNIFIED_IDEOGRAPHS) cjk=true;
            if (b==Character.UnicodeBlock.HIRAGANA || b==Character.UnicodeBlock.KATAKANA) kana=true;
            if (b==Character.UnicodeBlock.HANGUL_SYLLABLES) hangul=true;
            if (b==Character.UnicodeBlock.CYRILLIC) cyrillic=true;
            if (b==Character.UnicodeBlock.ARABIC) arabic=true;
            if (b==Character.UnicodeBlock.THAI) thai=true;
            if (b==Character.UnicodeBlock.DEVANAGARI) devanagari=true;
            if (Character.isLetter(c) && c < 0x024F) latin=true;

            if ("ăâđêôơưĂÂĐÊÔƠƯáàảãạấầẩẫậắằẳẵặéèẻẽẹếềểễệíìỉĩịóòỏõọốồổỗộớờởỡợúùủũụứừửữựýỳỷỹỵ".indexOf(c)>=0)
                vietnamese=true;
        }

        if (kana) return "ja";
        if (hangul) return "ko";
        if (cjk) return "zh";
        if (cyrillic) return "ru";
        if (arabic) return "ar";
        if (thai) return "th";
        if (devanagari) return "hi";
        if (vietnamese) return "vi";
        if (latin) return "en";
        return "und";
    }
}
