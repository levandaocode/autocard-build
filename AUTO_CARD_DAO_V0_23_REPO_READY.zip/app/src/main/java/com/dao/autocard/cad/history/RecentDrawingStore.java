package com.dao.autocard.cad.history;

import android.content.Context;
import android.content.SharedPreferences;
import java.util.*;

public final class RecentDrawingStore {
    private static final String PREF = "recent_drawings";
    private static final String KEY = "uris";
    private static final int LIMIT = 10;

    public void add(Context context, String uri) {
        if (context == null || uri == null || uri.isEmpty()) return;
        List<String> items = get(context);
        items.remove(uri);
        items.add(0, uri);
        while (items.size() > LIMIT) items.remove(items.size()-1);
        context.getSharedPreferences(PREF, Context.MODE_PRIVATE)
                .edit().putString(KEY, join(items)).apply();
    }

    public List<String> get(Context context) {
        String raw = context.getSharedPreferences(PREF, Context.MODE_PRIVATE)
                .getString(KEY, "");
        List<String> out = new ArrayList<>();
        if (!raw.isEmpty()) {
            for (String s : raw.split("\n")) if (!s.trim().isEmpty()) out.add(s);
        }
        return out;
    }

    private String join(List<String> list) {
        StringBuilder sb = new StringBuilder();
        for (String s : list) {
            if (sb.length() > 0) sb.append("\n");
            sb.append(s);
        }
        return sb.toString();
    }
}
