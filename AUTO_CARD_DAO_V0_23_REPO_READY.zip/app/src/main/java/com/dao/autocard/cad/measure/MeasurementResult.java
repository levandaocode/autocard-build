package com.dao.autocard.cad.measure;

public class MeasurementResult {
    public final String label;
    public final double value;
    public final String unit;

    public MeasurementResult(String label, double value, String unit) {
        this.label = label;
        this.value = value;
        this.unit = unit;
    }
}
