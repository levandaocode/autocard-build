package com.dao.autocard.cad.model;

import java.util.*;

public final class BlockDefinition {
    public final String name;
    public final Point2D basePoint;
    private final List<CadEntity> entities = new ArrayList<>();

    public BlockDefinition(String name, Point2D basePoint) {
        this.name = name == null ? "" : name;
        this.basePoint = basePoint;
    }

    public void add(CadEntity e) { if (e != null) entities.add(e); }
    public List<CadEntity> getEntities() { return Collections.unmodifiableList(entities); }
}
