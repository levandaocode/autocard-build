package com.dao.autocard.cad.model;

public abstract class CadEntity {
    private final EntityType type;
    private String layer = "0";

    protected CadEntity(EntityType type) {
        this.type = type;
    }

    public EntityType getType() { return type; }
    public String getLayer() { return layer; }
    public void setLayer(String layer) { this.layer = layer == null ? "0" : layer; }
}
