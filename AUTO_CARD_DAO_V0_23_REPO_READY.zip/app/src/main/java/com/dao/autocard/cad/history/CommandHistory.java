package com.dao.autocard.cad.history;

import java.util.ArrayDeque;
import java.util.Deque;

public final class CommandHistory {
    private final Deque<EditCommand> undo = new ArrayDeque<>();
    private final Deque<EditCommand> redo = new ArrayDeque<>();

    public void execute(EditCommand command) {
        if (command == null) return;
        command.execute();
        undo.push(command);
        redo.clear();
    }

    public boolean canUndo() { return !undo.isEmpty(); }
    public boolean canRedo() { return !redo.isEmpty(); }

    public String undo() {
        if (undo.isEmpty()) return null;
        EditCommand c = undo.pop();
        c.undo();
        redo.push(c);
        return c.getLabel();
    }

    public String redo() {
        if (redo.isEmpty()) return null;
        EditCommand c = redo.pop();
        c.execute();
        undo.push(c);
        return c.getLabel();
    }

    public void clear() {
        undo.clear();
        redo.clear();
    }
}
