package com.dao.autocard.cad.viewer;

import com.dao.autocard.cad.model.*;

public final class SelectionManager {
    public CadEntity findNearest(DrawingDocument doc, double worldX, double worldY, double tolerance) {
        if (doc == null) return null;
        CadEntity best = null;
        double bestD = Double.POSITIVE_INFINITY;

        for (CadEntity e : doc.getEntities()) {
            double d = distanceToEntity(e, worldX, worldY);
            if (d < tolerance && d < bestD) {
                bestD = d;
                best = e;
            }
        }
        return best;
    }

    private double distanceToEntity(CadEntity e, double x, double y) {
        if (e instanceof LineEntity) {
            LineEntity l=(LineEntity)e;
            return pointSegmentDistance(x,y,l.start.x,l.start.y,l.end.x,l.end.y);
        }
        if (e instanceof CircleEntity) {
            CircleEntity c=(CircleEntity)e;
            double dc=Math.hypot(x-c.center.x,y-c.center.y);
            return Math.abs(dc-c.radius);
        }
        if (e instanceof ArcEntity) {
            ArcEntity a=(ArcEntity)e;
            double dc=Math.hypot(x-a.center.x,y-a.center.y);
            return Math.abs(dc-a.radius);
        }
        if (e instanceof PolylineEntity) {
            PolylineEntity p=(PolylineEntity)e;
            double best=Double.POSITIVE_INFINITY;
            for(int i=1;i<p.getPoints().size();i++){
                Point2D a=p.getPoints().get(i-1), b=p.getPoints().get(i);
                best=Math.min(best,pointSegmentDistance(x,y,a.x,a.y,b.x,b.y));
            }
            return best;
        }
        if (e instanceof TextEntity) {
            TextEntity t=(TextEntity)e;
            return Math.hypot(x-t.position.x,y-t.position.y);
        }
        if (e instanceof EllipseEntity) {
            EllipseEntity el=(EllipseEntity)e;
            return Math.hypot(x-el.center.x,y-el.center.y);
        }
        if (e instanceof InsertEntity) {
            InsertEntity in=(InsertEntity)e;
            return Math.hypot(x-in.position.x,y-in.position.y);
        }
        return Double.POSITIVE_INFINITY;
    }

    private double pointSegmentDistance(double px,double py,double ax,double ay,double bx,double by){
        double vx=bx-ax, vy=by-ay;
        double wx=px-ax, wy=py-ay;
        double c1=vx*wx+vy*wy;
        if(c1<=0) return Math.hypot(px-ax,py-ay);
        double c2=vx*vx+vy*vy;
        if(c2<=c1) return Math.hypot(px-bx,py-by);
        double t=c1/c2;
        double qx=ax+t*vx, qy=ay+t*vy;
        return Math.hypot(px-qx,py-qy);
    }
}
