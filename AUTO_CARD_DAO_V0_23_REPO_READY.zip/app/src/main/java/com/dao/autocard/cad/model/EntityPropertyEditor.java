package com.dao.autocard.cad.model;

public final class EntityPropertyEditor {

    public boolean setLayer(CadEntity entity, String layer) {
        if (entity == null) return false;
        entity.setLayer(layer == null || layer.trim().isEmpty() ? "0" : layer.trim());
        return true;
    }

    public boolean setText(TextEntity entity, String text) {
        // TextEntity is immutable in geometry/content in the current model.
        // V0.7 will replace it with a mutable or copy-on-write entity model.
        return false;
    }
}
