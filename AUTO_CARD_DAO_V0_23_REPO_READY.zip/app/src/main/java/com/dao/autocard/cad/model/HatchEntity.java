package com.dao.autocard.cad.model;

import java.util.*;

public final class HatchEntity extends CadEntity {
    private final List<List<Point2D>> loops = new ArrayList<>();

    public HatchEntity() {
        super(EntityType.HATCH);
    }

    public void addLoop(List<Point2D> loop) {
        if (loop != null && !loop.isEmpty()) loops.add(new ArrayList<>(loop));
    }

    public List<List<Point2D>> getLoops() {
        List<List<Point2D>> out = new ArrayList<>();
        for (List<Point2D> l : loops) out.add(Collections.unmodifiableList(l));
        return Collections.unmodifiableList(out);
    }
}
