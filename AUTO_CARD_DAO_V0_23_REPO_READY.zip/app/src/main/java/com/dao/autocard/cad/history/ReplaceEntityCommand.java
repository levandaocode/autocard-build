package com.dao.autocard.cad.history;

import com.dao.autocard.cad.model.*;

public final class ReplaceEntityCommand implements EditCommand {
    private final DrawingDocument doc;
    private final CadEntity before;
    private final CadEntity after;
    private int index=-1;
    private final String label;

    public ReplaceEntityCommand(DrawingDocument doc,CadEntity before,CadEntity after,String label){
        this.doc=doc; this.before=before; this.after=after; this.label=label;
    }

    @Override public void execute(){
        if(doc==null || before==null || after==null) return;
        if(index<0) index=doc.indexOf(before);
        if(doc.remove(before)) doc.add(index,after);
        else if(doc.indexOf(after)<0) doc.add(index,after);
    }

    @Override public void undo(){
        if(doc==null) return;
        if(doc.remove(after)) doc.add(index,before);
    }

    @Override public String getLabel(){ return label; }
}
