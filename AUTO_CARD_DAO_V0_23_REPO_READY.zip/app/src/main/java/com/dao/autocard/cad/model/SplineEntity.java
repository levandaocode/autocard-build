package com.dao.autocard.cad.model;

import java.util.*;

public final class SplineEntity extends CadEntity {
    private final List<Point2D> controlPoints = new ArrayList<>();
    private final List<Point2D> fitPoints = new ArrayList<>();

    public SplineEntity() {
        super(EntityType.SPLINE);
    }

    public void addControlPoint(Point2D p) { if (p != null) controlPoints.add(p); }
    public void addFitPoint(Point2D p) { if (p != null) fitPoints.add(p); }

    public List<Point2D> getControlPoints() {
        return Collections.unmodifiableList(controlPoints);
    }

    public List<Point2D> getFitPoints() {
        return Collections.unmodifiableList(fitPoints);
    }
}
