package com.dao.autocard.cad.model;

public final class DimensionEntity extends CadEntity {
    public final Point2D definitionPoint;
    public final Point2D textPoint;
    public final String text;
    public final double measurement;

    public DimensionEntity(Point2D definitionPoint, Point2D textPoint, String text, double measurement) {
        super(EntityType.DIMENSION);
        this.definitionPoint = definitionPoint;
        this.textPoint = textPoint;
        this.text = text == null ? "" : text;
        this.measurement = measurement;
    }
}
