package com.dao.autocard.cad.model;

public final class CircleEntity extends CadEntity {
    public final Point2D center;
    public final double radius;

    public CircleEntity(Point2D center, double radius) {
        super(EntityType.CIRCLE);
        this.center = center;
        this.radius = radius;
    }
}
