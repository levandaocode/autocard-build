
package com.dao.autocard.cad.io;

public final class DwgNativeBridge {
    private static boolean loaded;

    static {
        try {
            System.loadLibrary("autocard_dwg");
            loaded = true;
        } catch (Throwable ignored) {
            loaded = false;
        }
    }

    private DwgNativeBridge() {}

    public static boolean isLoaded() {
        return loaded;
    }

    public static native String nativeVersion(byte[] bytes);
    public static native boolean nativeSupports(byte[] bytes);
    public static native String nativeParseSummary(byte[] bytes);
}
