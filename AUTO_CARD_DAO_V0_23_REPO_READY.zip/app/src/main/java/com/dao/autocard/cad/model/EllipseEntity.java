package com.dao.autocard.cad.model;

public final class EllipseEntity extends CadEntity {
    public final Point2D center;
    public final Point2D majorAxisVector;
    public final double ratio;
    public final double startParam;
    public final double endParam;

    public EllipseEntity(Point2D center, Point2D majorAxisVector, double ratio,
                         double startParam, double endParam) {
        super(EntityType.ELLIPSE);
        this.center = center;
        this.majorAxisVector = majorAxisVector;
        this.ratio = ratio;
        this.startParam = startParam;
        this.endParam = endParam;
    }

    public double majorRadius() {
        return Math.hypot(majorAxisVector.x, majorAxisVector.y);
    }

    public double minorRadius() {
        return majorRadius() * ratio;
    }
}
