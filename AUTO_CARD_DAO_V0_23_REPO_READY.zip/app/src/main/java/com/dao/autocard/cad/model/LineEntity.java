package com.dao.autocard.cad.model;

public final class LineEntity extends CadEntity {
    public final Point2D start;
    public final Point2D end;

    public LineEntity(Point2D start, Point2D end) {
        super(EntityType.LINE);
        this.start = start;
        this.end = end;
    }

    public double length() {
        return start.distanceTo(end);
    }
}
