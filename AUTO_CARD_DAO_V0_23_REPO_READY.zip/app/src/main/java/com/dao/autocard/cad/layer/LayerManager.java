package com.dao.autocard.cad.layer;

import com.dao.autocard.cad.model.CadEntity;
import com.dao.autocard.cad.model.DrawingDocument;
import java.util.*;

public class LayerManager {
    private final Map<String, Boolean> visibility = new LinkedHashMap<>();

    public void bindDocument(DrawingDocument doc) {
        visibility.clear();
        if (doc == null) return;
        for (CadEntity e : doc.getEntities()) {
            String name = e.getLayer();
            if (name == null || name.isEmpty()) name = "0";
            if (!visibility.containsKey(name)) visibility.put(name, true);
        }
    }

    public Set<String> getLayerNames() {
        return Collections.unmodifiableSet(visibility.keySet());
    }

    public boolean isVisible(String name) {
        Boolean value = visibility.get(name);
        return value == null || value;
    }

    public void setVisible(String name, boolean visible) {
        visibility.put(name, visible);
    }

    public void showAll() {
        for (String key : new ArrayList<>(visibility.keySet())) visibility.put(key, true);
    }

    public void hideAll() {
        for (String key : new ArrayList<>(visibility.keySet())) visibility.put(key, false);
    }
}
