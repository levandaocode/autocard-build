package com.dao.autocard.cad.text;

import com.dao.autocard.cad.model.TextEntity;
import java.util.Locale;

public class TextTranslationEngine {
    private final LanguageHeuristics detector = new LanguageHeuristics();
    private TranslationProvider provider;

    public TextTranslationEngine() {}

    public TextTranslationEngine(TranslationProvider provider) {
        this.provider = provider;
    }

    public void setProvider(TranslationProvider provider) {
        this.provider = provider;
    }

    public String getTargetLanguage() {
        String lang = Locale.getDefault().getLanguage();
        return lang == null || lang.isEmpty() ? "en" : lang;
    }

    public String detectLanguage(String text) {
        return detector.detect(text);
    }

    public boolean shouldTranslate(String sourceLanguage) {
        if (sourceLanguage == null || sourceLanguage.isEmpty() || "und".equals(sourceLanguage)) {
            return false;
        }
        return !sourceLanguage.equalsIgnoreCase(getTargetLanguage());
    }

    public void translate(TextEntity entity, final Callback callback) {
        if (entity == null) return;
        final String original = entity.text;
        final String source = detectLanguage(original);
        final String target = getTargetLanguage();

        if (!shouldTranslate(source)) {
            if (callback != null) callback.onResult(
                    new TranslatedText(original, original, source, target));
            return;
        }

        if (provider == null) {
            if (callback != null) callback.onResult(
                    new TranslatedText(original, original, source, target));
            return;
        }

        provider.translate(original, source, target, new TranslationProvider.Callback() {
            @Override public void onSuccess(String translated) {
                if (callback != null) callback.onResult(
                        new TranslatedText(original, translated, source, target));
            }

            @Override public void onFailure(Throwable error) {
                if (callback != null) callback.onResult(
                        new TranslatedText(original, original, source, target));
            }
        });
    }

    public interface Callback {
        void onResult(TranslatedText result);
    }
}
