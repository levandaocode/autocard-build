package com.dao.autocard.cad.measure;

import com.dao.autocard.cad.model.Point2D;

public final class MeasurementOverlayItem {
    public final Point2D anchor;
    public final String label;

    public MeasurementOverlayItem(Point2D anchor, String label) {
        this.anchor = anchor;
        this.label = label;
    }
}
