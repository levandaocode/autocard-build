package com.dao.autocard.cad.viewer;

import com.dao.autocard.cad.model.Point2D;
import java.util.*;

public final class SplineInterpolator {

    public List<Point2D> interpolateCatmullRom(List<Point2D> src, int stepsPerSegment) {
        List<Point2D> out = new ArrayList<>();
        if (src == null || src.size() < 2) return out;
        if (src.size() == 2) {
            out.addAll(src);
            return out;
        }

        int steps = Math.max(4, stepsPerSegment);

        for (int i = 0; i < src.size() - 1; i++) {
            Point2D p0 = src.get(Math.max(i - 1, 0));
            Point2D p1 = src.get(i);
            Point2D p2 = src.get(i + 1);
            Point2D p3 = src.get(Math.min(i + 2, src.size() - 1));

            for (int s = 0; s < steps; s++) {
                double t = s / (double) steps;
                double t2 = t * t;
                double t3 = t2 * t;

                double x = 0.5 * ((2 * p1.x) +
                        (-p0.x + p2.x) * t +
                        (2*p0.x - 5*p1.x + 4*p2.x - p3.x) * t2 +
                        (-p0.x + 3*p1.x - 3*p2.x + p3.x) * t3);

                double y = 0.5 * ((2 * p1.y) +
                        (-p0.y + p2.y) * t +
                        (2*p0.y - 5*p1.y + 4*p2.y - p3.y) * t2 +
                        (-p0.y + 3*p1.y - 3*p2.y + p3.y) * t3);

                out.add(new Point2D(x, y));
            }
        }

        out.add(src.get(src.size()-1));
        return out;
    }
}
