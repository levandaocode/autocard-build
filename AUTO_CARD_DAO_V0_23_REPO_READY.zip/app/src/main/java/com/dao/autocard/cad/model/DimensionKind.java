package com.dao.autocard.cad.model;

public enum DimensionKind {
    LINEAR, ALIGNED, ANGULAR, RADIUS, DIAMETER, ORDINATE, UNKNOWN
}
