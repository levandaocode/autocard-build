package com.dao.autocard.cad.viewer;

import android.content.Context;
import android.graphics.*;
import android.view.*;
import com.dao.autocard.cad.layer.LayerManager;
import com.dao.autocard.cad.measure.*;
import com.dao.autocard.cad.model.*;
import com.dao.autocard.cad.text.*;
import java.util.List;

public class CadViewerView extends View {
    private final Paint stroke = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint selectedPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint textPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint overlayPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final ScaleGestureDetector scaleDetector;
    private final SelectionManager selectionManager = new SelectionManager();
    private final BlockRenderer blockRenderer = new BlockRenderer();
    private final SplineInterpolator splineInterpolator = new SplineInterpolator();
    private final MeasurementOverlay overlay = new MeasurementOverlay();
    private final GripManager gripManager = new GripManager();
    private EditMode editMode = EditMode.SELECT;
    private Point2D pickedPivot = new Point2D(0,0);
    private Point2D dragStartWorld;
    private GeometryTransform geometryTransform = new GeometryTransform();
    private DrawingDocument mutableDocument;
    private GeometryEditListener geometryEditListener;
    private final TranslationStore translationStore = new TranslationStore();
    private TextDisplayMode textDisplayMode = TextDisplayMode.ORIGINAL;

    private DrawingDocument document;
    private LayerManager layers;
    private CadEntity selected;
    private boolean overlayVisible = false;

    private float scale=1f, offsetX=0f, offsetY=0f;
    private float lastX,lastY,downX,downY;
    private boolean dragging;

    public CadViewerView(Context context) {
        super(context);
        stroke.setStrokeWidth(1.5f);
        stroke.setStyle(Paint.Style.STROKE);
        stroke.setColor(Color.BLACK);

        selectedPaint.setStrokeWidth(4f);
        selectedPaint.setStyle(Paint.Style.STROKE);
        selectedPaint.setColor(Color.RED);

        textPaint.setTextSize(14f);
        textPaint.setColor(Color.BLACK);

        overlayPaint.setTextSize(12f);
        overlayPaint.setColor(Color.BLUE);
        overlayPaint.setStyle(Paint.Style.FILL);

        scaleDetector = new ScaleGestureDetector(context,
            new ScaleGestureDetector.SimpleOnScaleGestureListener(){
                @Override public boolean onScale(ScaleGestureDetector d){
                    scale*=d.getScaleFactor();
                    if(scale<0.02f) scale=0.02f;
                    if(scale>200f) scale=200f;
                    invalidate();
                    return true;
                }
            });
    }

    public void setDocument(DrawingDocument doc,LayerManager layerManager){
        document=doc; mutableDocument=doc; layers=layerManager; selected=null;
        overlay.rebuild(doc);
        fitToScreen(); invalidate();
    }

    public CadEntity getSelectedEntity(){ return selected; }

    public void setEditMode(EditMode mode) { editMode = mode == null ? EditMode.SELECT : mode; }
    public EditMode getEditMode() { return editMode; }
    public Point2D getPickedPivot() { return pickedPivot; }
    public void setGeometryEditListener(GeometryEditListener listener) { geometryEditListener = listener; }

    public void setSelectedEntity(CadEntity entity) {
        selected = entity;
        invalidate();
    }

    public void setMeasurementOverlayVisible(boolean visible){
        overlayVisible=visible;
        if(visible) overlay.rebuild(document);
        invalidate();
    }

    public boolean isMeasurementOverlayVisible(){ return overlayVisible; }

    public TranslationStore getTranslationStore() { return translationStore; }

    public void setTextDisplayMode(TextDisplayMode mode) {
        if (mode != null) textDisplayMode = mode;
        invalidate();
    }

    public TextDisplayMode getTextDisplayMode() {
        return textDisplayMode;
    }

    public void fitToScreen(){
        if(document==null || getWidth()<=0 || getHeight()<=0) return;
        DrawingBounds b=document.getBounds();
        if(!b.isValid()) return;
        double bw=Math.max(b.width(),1e-6), bh=Math.max(b.height(),1e-6);
        float sx=(float)((getWidth()*0.9)/bw);
        float sy=(float)((getHeight()*0.9)/bh);
        scale=Math.min(sx,sy);
        offsetX=getWidth()/2f-(float)(b.centerX()*scale);
        offsetY=getHeight()/2f+(float)(b.centerY()*scale);
        invalidate();
    }

    @Override protected void onSizeChanged(int w,int h,int oldw,int oldh){ fitToScreen(); }

    private float sx(double x){ return offsetX+(float)(x*scale); }
    private float sy(double y){ return offsetY-(float)(y*scale); }
    private double wx(float sx){ return (sx-offsetX)/scale; }
    private double wy(float sy){ return -(sy-offsetY)/scale; }

    @Override protected void onDraw(Canvas canvas){
        super.onDraw(canvas);
        canvas.drawColor(Color.WHITE);
        if(document==null) return;

        for(CadEntity e:document.getEntities()){
            if(layers!=null && !layers.isVisible(e.getLayer())) continue;
            Paint p=e==selected?selectedPaint:stroke;
            drawEntity(canvas,e,p);
        }

        if(selected != null) {
            Paint gripPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
            gripPaint.setStyle(Paint.Style.FILL);
            gripPaint.setColor(Color.MAGENTA);
            for(Point2D g : gripManager.getGrips(selected)) {
                canvas.drawCircle(sx(g.x), sy(g.y), 7f, gripPaint);
            }
        }

        if(editMode == EditMode.PICK_PIVOT) {
            Paint pivotPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
            pivotPaint.setColor(Color.GREEN);
            pivotPaint.setStrokeWidth(3f);
            float px=sx(pickedPivot.x), py=sy(pickedPivot.y);
            canvas.drawLine(px-10,py,px+10,py,pivotPaint);
            canvas.drawLine(px,py-10,px,py+10,pivotPaint);
        }

        if(overlayVisible){
            for(MeasurementOverlayItem item:overlay.getItems()){
                canvas.drawText(item.label,sx(item.anchor.x),sy(item.anchor.y),overlayPaint);
            }
        }
    }

    private void drawEntity(Canvas canvas,CadEntity e,Paint p){
        if(e instanceof LineEntity){
            LineEntity x=(LineEntity)e;
            canvas.drawLine(sx(x.start.x),sy(x.start.y),sx(x.end.x),sy(x.end.y),p);

        } else if(e instanceof CircleEntity){
            CircleEntity x=(CircleEntity)e;
            canvas.drawCircle(sx(x.center.x),sy(x.center.y),(float)(x.radius*scale),p);

        } else if(e instanceof ArcEntity){
            ArcEntity x=(ArcEntity)e;
            float r=(float)(x.radius*scale);
            RectF rect=new RectF(sx(x.center.x)-r,sy(x.center.y)-r,
                                 sx(x.center.x)+r,sy(x.center.y)+r);
            canvas.drawArc(rect,(float)-x.startAngleDeg,(float)-x.sweepDeg(),false,p);

        } else if(e instanceof PolylineEntity){
            PolylineEntity x=(PolylineEntity)e;
            if(x.getPoints().isEmpty()) return;
            Path path=new Path();
            Point2D p0=x.getPoints().get(0);
            path.moveTo(sx(p0.x),sy(p0.y));
            for(int i=1;i<x.getPoints().size();i++){
                Point2D q=x.getPoints().get(i);
                path.lineTo(sx(q.x),sy(q.y));
            }
            if(x.isClosed()) path.close();
            canvas.drawPath(path,p);

        } else if(e instanceof TextEntity){
            TextEntity x=(TextEntity)e;
            float old=textPaint.getTextSize();
            textPaint.setTextSize(Math.max(10f,(float)(x.height*scale)));

            String display=x.text;
            TranslatedText tr=translationStore.get(x);

            if (tr != null) {
                if (textDisplayMode == TextDisplayMode.TRANSLATED) {
                    display=tr.translated;
                } else if (textDisplayMode == TextDisplayMode.BILINGUAL) {
                    display=tr.original + " | " + tr.translated;
                }
            }

            canvas.save();
            canvas.rotate((float)-x.rotationDeg,sx(x.position.x),sy(x.position.y));
            String[] lines=display.split("\\n");
            float y=sy(x.position.y);
            for (String line : lines) {
                canvas.drawText(line,sx(x.position.x),y,textPaint);
                y += textPaint.getTextSize()*1.15f;
            }
            canvas.restore();
            textPaint.setTextSize(old);

        } else if(e instanceof EllipseEntity){
            EllipseEntity x=(EllipseEntity)e;
            float a=(float)(x.majorRadius()*scale);
            float b=(float)(x.minorRadius()*scale);
            double angle=Math.atan2(x.majorAxisVector.y,x.majorAxisVector.x);
            canvas.save();
            canvas.rotate((float)-Math.toDegrees(angle),sx(x.center.x),sy(x.center.y));
            RectF rect=new RectF(sx(x.center.x)-a,sy(x.center.y)-b,
                                 sx(x.center.x)+a,sy(x.center.y)+b);
            float start=(float)-Math.toDegrees(x.startParam);
            float sweep=(float)-Math.toDegrees(x.endParam-x.startParam);
            canvas.drawArc(rect,start,sweep,false,p);
            canvas.restore();

        } else if(e instanceof SplineEntity){
            SplineEntity x=(SplineEntity)e;
            List<Point2D> raw=!x.getFitPoints().isEmpty()?x.getFitPoints():x.getControlPoints();
            List<Point2D> pts=splineInterpolator.interpolateCatmullRom(raw,12);
            if(pts.size()<2) return;
            Path path=new Path();
            path.moveTo(sx(pts.get(0).x),sy(pts.get(0).y));
            for(int i=1;i<pts.size();i++) path.lineTo(sx(pts.get(i).x),sy(pts.get(i).y));
            canvas.drawPath(path,p);

        } else if(e instanceof DimensionEntity){
            DimensionEntity x=(DimensionEntity)e;
            canvas.drawLine(sx(x.definitionPoint.x),sy(x.definitionPoint.y),
                            sx(x.textPoint.x),sy(x.textPoint.y),p);
            drawArrow(canvas, x.definitionPoint, x.textPoint, p);
            String label=x.text==null || x.text.isEmpty() ?
                    String.format(java.util.Locale.US,"%.3f",x.measurement) : x.text;
            canvas.drawText(label,sx(x.textPoint.x),sy(x.textPoint.y),textPaint);

        } else if(e instanceof HatchEntity){
            HatchEntity x=(HatchEntity)e;
            Paint fill = new Paint(Paint.ANTI_ALIAS_FLAG);
            fill.setStyle(Paint.Style.FILL);
            fill.setColor(Color.LTGRAY);
            for(java.util.List<Point2D> loop:x.getLoops()){
                if(loop.isEmpty()) continue;
                Path path=new Path();
                path.moveTo(sx(loop.get(0).x),sy(loop.get(0).y));
                for(int i=1;i<loop.size();i++)
                    path.lineTo(sx(loop.get(i).x),sy(loop.get(i).y));
                path.close();
                canvas.drawPath(path,fill);
                canvas.drawPath(path,p);
            }

        } else if(e instanceof LeaderEntity){
            LeaderEntity x=(LeaderEntity)e;
            if(x.getPoints().size()<2) return;
            Path path=new Path();
            path.moveTo(sx(x.getPoints().get(0).x),sy(x.getPoints().get(0).y));
            for(int i=1;i<x.getPoints().size();i++)
                path.lineTo(sx(x.getPoints().get(i).x),sy(x.getPoints().get(i).y));
            canvas.drawPath(path,p);
            if(x.getPoints().size()>=2)
                drawArrow(canvas,x.getPoints().get(1),x.getPoints().get(0),p);

        } else if(e instanceof InsertEntity){
            final InsertEntity x=(InsertEntity)e;
            blockRenderer.drawInsert(canvas, document, x, p, new BlockRenderer.WorldToScreen() {
                @Override public float sx(double v) { return CadViewerView.this.sx(v); }
                @Override public float sy(double v) { return CadViewerView.this.sy(v); }
                @Override public float scale() { return CadViewerView.this.scale; }
            });
        }
    }


    private void drawArrow(Canvas canvas, Point2D from, Point2D to, Paint paint) {
        double a=Math.atan2(to.y-from.y,to.x-from.x);
        double len=10.0/Math.max(scale,0.001f);
        double a1=a+Math.toRadians(150), a2=a-Math.toRadians(150);
        Point2D p1=new Point2D(to.x+Math.cos(a1)*len,to.y+Math.sin(a1)*len);
        Point2D p2=new Point2D(to.x+Math.cos(a2)*len,to.y+Math.sin(a2)*len);
        Path path=new Path();
        path.moveTo(sx(to.x),sy(to.y));
        path.lineTo(sx(p1.x),sy(p1.y));
        path.lineTo(sx(p2.x),sy(p2.y));
        path.close();
        Paint fill=new Paint(paint);
        fill.setStyle(Paint.Style.FILL);
        canvas.drawPath(path,fill);
    }

    @Override public boolean onTouchEvent(MotionEvent event){
        scaleDetector.onTouchEvent(event);
        switch(event.getActionMasked()){
            case MotionEvent.ACTION_DOWN:
                lastX=downX=event.getX(); lastY=downY=event.getY();
                if(editMode == EditMode.DRAG_MOVE && selected != null) {
                    dragStartWorld = new Point2D(wx(event.getX()), wy(event.getY()));
                    dragging=false;
                    return true;
                }
                dragging=true; return true;
            case MotionEvent.ACTION_MOVE:
                if(dragging && !scaleDetector.isInProgress()){
                    float x=event.getX(), y=event.getY();
                    offsetX+=x-lastX; offsetY+=y-lastY;
                    lastX=x; lastY=y; invalidate();
                }
                return true;
            case MotionEvent.ACTION_UP:
                if(editMode == EditMode.PICK_PIVOT) {
                    pickedPivot = new Point2D(wx(event.getX()), wy(event.getY()));
                    invalidate();
                    return true;
                }
                if(editMode == EditMode.DRAG_MOVE && selected != null && dragStartWorld != null) {
                    Point2D end = new Point2D(wx(event.getX()), wy(event.getY()));
                    double mdx=end.x-dragStartWorld.x, mdy=end.y-dragStartWorld.y;
                    CadEntity before = selected;
                    CadEntity moved = geometryTransform.move(before,mdx,mdy);
                    if(geometryEditListener != null) {
                        geometryEditListener.onReplaceRequested(before,moved,"Kéo Move");
                    } else {
                        int idx = mutableDocument.indexOf(before);
                        if(idx>=0) {
                            mutableDocument.remove(before);
                            mutableDocument.add(idx,moved);
                            selected=moved;
                        }
                    }
                    dragStartWorld=null;
                    invalidate();
                    return true;
                }
                dragging=false;
                float dx=event.getX()-downX, dy=event.getY()-downY;
                if(Math.hypot(dx,dy)<16 && document!=null){
                    double tolerance=20.0/Math.max(scale,0.001f);
                    selected=selectionManager.findNearest(document,wx(event.getX()),wy(event.getY()),tolerance);
                    invalidate();
                }
                return true;
            case MotionEvent.ACTION_CANCEL:
                dragging=false; return true;
        }
        return true;
    }
}
