package com.dao.autocard.cad.model;

public final class HatchStyle {
    public final String patternName;
    public final boolean solid;

    public HatchStyle(String patternName, boolean solid) {
        this.patternName = patternName == null ? "" : patternName;
        this.solid = solid;
    }
}
