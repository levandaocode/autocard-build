package com.dao.autocard.cad.history;

import com.dao.autocard.cad.model.*;

public final class DeleteEntityCommand implements EditCommand {
    private final DrawingDocument doc;
    private final CadEntity entity;
    private int index=-1;

    public DeleteEntityCommand(DrawingDocument doc,CadEntity entity){ this.doc=doc; this.entity=entity; }

    @Override public void execute(){
        if(doc==null || entity==null) return;
        if(index<0) index=doc.indexOf(entity);
        doc.remove(entity);
    }

    @Override public void undo(){ if(doc!=null && entity!=null) doc.add(index,entity); }
    @Override public String getLabel(){ return "Xóa đối tượng"; }
}
