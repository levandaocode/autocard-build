package com.dao.autocard.cad.viewer;

public enum EditMode {
    SELECT,
    PICK_PIVOT,
    DRAG_MOVE
}
