package com.dao.autocard.cad.model;

import java.util.*;

public final class LeaderEntity extends CadEntity {
    private final List<Point2D> points = new ArrayList<>();
    private final boolean multi;

    public LeaderEntity(boolean multi) {
        super(multi ? EntityType.MLEADER : EntityType.LEADER);
        this.multi = multi;
    }

    public void addPoint(Point2D p) { if (p != null) points.add(p); }
    public List<Point2D> getPoints() { return Collections.unmodifiableList(points); }
    public boolean isMultiLeader() { return multi; }
}
