package com.dao.autocard.cad.io;

public final class DwgEngineRegistry {
    private DwgEngine engine;

    public void setEngine(DwgEngine engine) {
        this.engine = engine;
    }

    public DwgEngine getEngine() {
        return engine;
    }

    public boolean hasEngineFor(String version) {
        return engine != null && engine.supportsVersion(version);
    }
}
