package com.dao.autocard;

import android.app.*;
import android.content.*;
import android.net.Uri;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.*;

import com.dao.autocard.cad.layer.LayerManager;
import com.dao.autocard.cad.model.DrawingDocument;
import com.dao.autocard.cad.parser.DxfParser;
import com.dao.autocard.cad.measure.MeasureEngine;
import com.dao.autocard.cad.measure.MeasurementResult;
import com.dao.autocard.cad.viewer.CadViewerView;
import com.dao.autocard.cad.io.*;
import com.dao.autocard.cad.text.*;
import com.dao.autocard.cad.export.ExportEngine;
import com.dao.autocard.cad.export.ShareHelper;
import com.dao.autocard.cad.model.TextEntity;
import com.dao.autocard.cad.model.CadEntity;
import com.dao.autocard.cad.writer.DxfWriter;
import com.dao.autocard.cad.history.*;
import com.dao.autocard.cad.recovery.RecoveryManager;
import com.dao.autocard.cad.model.GeometryTransform;

import java.io.InputStream;
import java.util.*;

public class MainActivity extends Activity {
    private static final int REQ_OPEN_DXF = 1001;

    private CadViewerView viewer;
    private DwgWebEngineView dwgViewer;
    private android.widget.FrameLayout canvasHost;
    private TextView statusView;
    private DrawingDocument document = new DrawingDocument();
    private final LayerManager layerManager = new LayerManager();
    private final DxfParser parser = new DxfParser();
    private final CadFileDetector cadFileDetector = new CadFileDetector();
    private final DwgEngineRegistry dwgEngineRegistry = new DwgEngineRegistry();
    private final TextTranslationEngine translationEngine = new TextTranslationEngine();
    private final ExportEngine exportEngine = new ExportEngine();
    private BatchTranslationEngine batchTranslationEngine;
    private final ShareHelper shareHelper = new ShareHelper();
    private final DxfWriter dxfWriter = new DxfWriter();
    private final CommandHistory commandHistory = new CommandHistory();
    private final RecentDrawingStore recentDrawingStore = new RecentDrawingStore();
    private final RecoveryManager recoveryManager = new RecoveryManager();
    private final GeometryTransform geometryTransform = new GeometryTransform();
    private java.io.File lastExportedFile;
    private String lastExportMime;

    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);

        TextView title = new TextView(this);
        title.setText("AUTO CARD ĐẠO");
        title.setTextSize(22f);
        title.setGravity(Gravity.CENTER);
        title.setPadding(12,18,12,18);
        root.addView(title);

        statusView = new TextView(this);
        statusView.setText("Chưa mở bản vẽ");
        statusView.setTextSize(12f);
        statusView.setPadding(dp(10), dp(4), dp(10), dp(6));
        root.addView(statusView);

        viewer = new CadViewerView(this);
        dwgViewer = new DwgWebEngineView(this);
        dwgViewer.setVisibility(View.GONE);

        canvasHost = new android.widget.FrameLayout(this);
        canvasHost.addView(viewer, new android.widget.FrameLayout.LayoutParams(
                android.widget.FrameLayout.LayoutParams.MATCH_PARENT,
                android.widget.FrameLayout.LayoutParams.MATCH_PARENT));
        canvasHost.addView(dwgViewer, new android.widget.FrameLayout.LayoutParams(
                android.widget.FrameLayout.LayoutParams.MATCH_PARENT,
                android.widget.FrameLayout.LayoutParams.MATCH_PARENT));

        root.addView(canvasHost, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,0,1f));

        LinearLayout menuBar = new LinearLayout(this);
        menuBar.setOrientation(LinearLayout.HORIZONTAL);
        menuBar.setPadding(dp(4), dp(2), dp(4), dp(2));

        menuBar.addView(makeButton("TỆP", v -> showFileMenu()));
        menuBar.addView(makeButton("XEM", v -> showViewMenu()));
        menuBar.addView(makeButton("ĐO LƯỜNG", v -> showMeasureMenu()));
        menuBar.addView(makeButton("CHỈNH SỬA", v -> showEditMenu()));
        menuBar.addView(makeButton("NGÔN NGỮ", v -> showLanguageMenu()));
        menuBar.addView(makeButton("CÀI ĐẶT", v -> showSettingsMenu()));

        root.addView(scrollTools(menuBar));

        setContentView(root);

        dwgViewer.setListener(new DwgWebEngineView.Listener() {
            @Override public void onReady() {
                // Engine tải xong; file chờ (nếu có) sẽ tự chạy.
            }

            @Override public void onRendered(int entityCount, int layerCount, String version) {
                statusView.setText("DWG • " + entityCount + " đối tượng • " +
                        layerCount + " layer" +
                        (version == null || version.isEmpty() ? "" : " • " + version));
                Toast.makeText(MainActivity.this,
                        "Đã hiển thị DWG: " + entityCount + " đối tượng",
                        Toast.LENGTH_LONG).show();
            }

            @Override public void onError(String message) {
                new AlertDialog.Builder(MainActivity.this)
                        .setTitle("DWG ENGINE")
                        .setMessage(message == null ? "Không giải mã được DWG" : message)
                        .setPositiveButton("OK",null)
                        .show();
            }
        });

        translationEngine.setProvider(new SystemTranslationProvider(this));
        batchTranslationEngine = new BatchTranslationEngine(translationEngine);
        if (DwgNativeBridge.isLoaded()) dwgEngineRegistry.setEngine(new DwgNativeEngine());
        viewer.setGeometryEditListener((before,after,label) -> {
            commandHistory.execute(new ReplaceEntityCommand(document,before,after,label));
            viewer.setSelectedEntity(after);
            layerManager.bindDocument(document);
            viewer.invalidate();
            try { recoveryManager.autosave(this,document); } catch(Exception ignored) {}
        });
        offerRecoveryIfAvailable();
        viewer.setDocument(document, layerManager);

        new AlertDialog.Builder(this)
                .setTitle("AUTO CARD ĐẠO")
                .setMessage("AUTO CARD ĐẠO V0.21\nCSKH: 0868341900")
                .setPositiveButton("Tiếp tục", null)
                .show();
    }

    private Button makeButton(String text, View.OnClickListener listener) {
        Button b = new Button(this);
        b.setText(text);
        b.setTextSize(12f);
        b.setSingleLine(true);
        b.setMinWidth(dp(110));
        b.setMinimumWidth(dp(110));
        b.setPadding(dp(12), dp(5), dp(12), dp(5));
        b.setOnClickListener(listener);
        return b;
    }

    private int dp(int value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }

    private android.widget.HorizontalScrollView scrollTools(LinearLayout row) {
        android.widget.HorizontalScrollView scroll = new android.widget.HorizontalScrollView(this);
        scroll.setHorizontalScrollBarEnabled(false);
        scroll.setFillViewport(false);
        scroll.addView(row);
        return scroll;
    }


    private void showFileMenu() {
        final String[] items = {
                "Mở bản vẽ", "Mở mẫu", "Bản vẽ gần đây",
                "Lưu DXF", "Xuất PNG", "Xuất PDF", "Chia sẻ file đã xuất"
        };
        new AlertDialog.Builder(this)
                .setTitle("TỆP")
                .setItems(items,(d,which)->{
                    switch(which){
                        case 0: openDxf(); break;
                        case 1: openDemoDxf(); break;
                        case 2: showRecentDrawings(); break;
                        case 3: saveDxf(); break;
                        case 4: exportPng(); break;
                        case 5: exportPdf(); break;
                        case 6: shareLastExport(); break;
                    }
                }).show();
    }

    private void showViewMenu() {
        final String[] items = {
                "Vừa màn hình", "Layer", "Lớp thông số",
                "Chế độ chữ", "Thông tin chi tiết"
        };
        new AlertDialog.Builder(this)
                .setTitle("XEM")
                .setItems(items,(d,which)->{
                    switch(which){
                        case 0:
                            if (dwgViewer != null && dwgViewer.getVisibility() == View.VISIBLE) {
                                dwgViewer.evaluateJavascript(
                                        "(function(){const s=document.querySelector('#stage svg');" +
                                        "if(s){s.style.width='100%';s.style.height='100%';}})()",null);
                            } else viewer.fitToScreen();
                            break;
                        case 1: showLayers(); break;
                        case 2: viewer.setMeasurementOverlayVisible(!viewer.isMeasurementOverlayVisible()); break;
                        case 3: chooseTextMode(); break;
                        case 4: showSelectedEntity(); break;
                    }
                }).show();
    }

    private void showMeasureMenu() {
        final String[] items = {
                "Hiện toàn bộ thông số",
                "Thông tin chi tiết",
                "Lớp kích thước"
        };
        new AlertDialog.Builder(this)
                .setTitle("ĐO LƯỜNG")
                .setItems(items,(d,which)->{
                    switch(which){
                        case 0: showMeasurements(); break;
                        case 1: showSelectedEntity(); break;
                        case 2: viewer.setMeasurementOverlayVisible(!viewer.isMeasurementOverlayVisible()); break;
                    }
                }).show();
    }

    private void showEditMenu() {
        final String[] items = {
                "Di chuyển", "Xoay", "Tỷ lệ", "Xóa", "Nhân bản",
                "Điểm chỉnh", "Thuộc tính", "Undo", "Redo",
                "Chọn tâm", "Kéo di chuyển"
        };
        new AlertDialog.Builder(this)
                .setTitle("CHỈNH SỬA")
                .setItems(items,(d,which)->{
                    switch(which){
                        case 0: moveSelected(); break;
                        case 1: rotateSelected(); break;
                        case 2: scaleSelected(); break;
                        case 3: deleteSelected(); break;
                        case 4: duplicateSelected(); break;
                        case 5: editGrip(); break;
                        case 6: editSelectedProperties(); break;
                        case 7: undoEdit(); break;
                        case 8: redoEdit(); break;
                        case 9:
                            viewer.setEditMode(com.dao.autocard.cad.viewer.EditMode.PICK_PIVOT);
                            Toast.makeText(this,"Chạm vị trí làm tâm trên bản vẽ",Toast.LENGTH_SHORT).show();
                            break;
                        case 10:
                            viewer.setEditMode(com.dao.autocard.cad.viewer.EditMode.DRAG_MOVE);
                            Toast.makeText(this,"Chọn đối tượng rồi kéo tới vị trí mới",Toast.LENGTH_SHORT).show();
                            break;
                    }
                }).show();
    }

    private void showLanguageMenu() {
        final String[] items = {
                "Dịch văn bản đang chọn",
                "Dịch toàn bộ văn bản",
                "Bản gốc / Song ngữ / Bản dịch"
        };
        new AlertDialog.Builder(this)
                .setTitle("NGÔN NGỮ")
                .setItems(items,(d,which)->{
                    switch(which){
                        case 0: translateSelectedText(); break;
                        case 1: translateAllText(); break;
                        case 2: chooseTextMode(); break;
                    }
                }).show();
    }

    private void showSettingsMenu() {
        final String[] items = {
                "Khôi phục autosave",
                "Xóa autosave",
                "CSKH 0868341900",
                "Giới thiệu AUTO CARD ĐẠO"
        };
        new AlertDialog.Builder(this)
                .setTitle("CÀI ĐẶT")
                .setItems(items,(d,which)->{
                    switch(which){
                        case 0: offerRecoveryIfAvailable(); break;
                        case 1:
                            recoveryManager.clear(this);
                            Toast.makeText(this,"Đã xóa autosave",Toast.LENGTH_SHORT).show();
                            break;
                        case 2:
                            new AlertDialog.Builder(this)
                                    .setTitle("CSKH")
                                    .setMessage("0868341900\\nNhóm Zalo hỗ trợ đã cấu hình trong dự án.")
                                    .setPositiveButton("OK",null)
                                    .show();
                            break;
                        case 3:
                            new AlertDialog.Builder(this)
                                    .setTitle("AUTO CARD ĐẠO")
                                    .setMessage("AUTO CARD ĐẠO V0.20\\nMàn hình ngang • Menu phân nhóm • Trình xem/chỉnh sửa CAD")
                                    .setPositiveButton("OK",null)
                                    .show();
                            break;
                    }
                }).show();
    }

    private void openDemoDxf() {
        showNativeCadViewer();
        try (java.io.InputStream in = getResources().openRawResource(
                getResources().getIdentifier("demo_drawing","raw",getPackageName()))) {
            document = parser.parse(in);
            layerManager.bindDocument(document);
            commandHistory.clear();
            viewer.setDocument(document,layerManager);
            updateStatus("Mẫu");
            showDiagnosticsIfNeeded();
            Toast.makeText(this,"Đã mở bản vẽ mẫu",Toast.LENGTH_SHORT).show();
        } catch(Exception e) {
            new AlertDialog.Builder(this)
                    .setTitle("Không mở được bản mẫu")
                    .setMessage(e.toString())
                    .setPositiveButton("OK",null)
                    .show();
        }
    }

    private void updateStatus(String source) {
        if (statusView == null) return;
        int entityCount = document == null ? 0 : document.getEntities().size();
        int layerCount = layerManager.getLayerNames().size();
        statusView.setText(source + " • " + entityCount + " đối tượng • " +
                layerCount + " layer");
    }

    private void showDiagnosticsIfNeeded() {
        com.dao.autocard.cad.parser.ParseDiagnostics d = parser.getDiagnostics();
        if (d != null && d.hasUnsupported()) {
            new AlertDialog.Builder(this)
                    .setTitle("Entity chưa hỗ trợ")
                    .setMessage(d.summary())
                    .setPositiveButton("OK",null)
                    .show();
        }
    }


    private void showNativeCadViewer() {
        if (viewer != null) viewer.setVisibility(View.VISIBLE);
        if (dwgViewer != null) dwgViewer.setVisibility(View.GONE);
    }

    private void showDwgViewer() {
        if (viewer != null) viewer.setVisibility(View.GONE);
        if (dwgViewer != null) dwgViewer.setVisibility(View.VISIBLE);
    }

    private void openCadUri(Uri uri, String displayName) {
        if (uri == null) return;
        try (InputStream raw = getContentResolver().openInputStream(uri)) {
            if (raw == null) throw new java.io.IOException("Không đọc được file");
            openCadStream(raw, displayName == null ? "Bản vẽ" : displayName);
        } catch (Exception e) {
            new AlertDialog.Builder(this)
                    .setTitle("Không mở được bản vẽ")
                    .setMessage(e.getMessage() == null ? e.toString() : e.getMessage())
                    .setPositiveButton("OK",null)
                    .show();
        }
    }

    private void openCadStream(InputStream raw, String displayName) throws Exception {
        java.io.BufferedInputStream in = raw instanceof java.io.BufferedInputStream
                ? (java.io.BufferedInputStream) raw
                : new java.io.BufferedInputStream(raw);

        // Read enough bytes once, then recreate streams so detection can never
        // consume bytes needed by the real parser/engine.
        java.io.ByteArrayOutputStream buffer = new java.io.ByteArrayOutputStream();
        byte[] chunk = new byte[16384];
        int n;
        while ((n = in.read(chunk)) != -1) buffer.write(chunk,0,n);
        byte[] bytes = buffer.toByteArray();

        CadFileType type = cadFileDetector.detect(new java.io.ByteArrayInputStream(bytes));

        if (type == CadFileType.DWG) {
            String version = cadFileDetector.readDwgVersion(
                    new java.io.ByteArrayInputStream(bytes));

            showDwgViewer();
            statusView.setText("DWG " + version + " • đang giải mã...");
            dwgViewer.renderDwg(bytes, displayName);
            return;
        }

        if (type == CadFileType.DXF) {
            showNativeCadViewer();
            document = parser.parse(new java.io.ByteArrayInputStream(bytes));
            layerManager.bindDocument(document);
            commandHistory.clear();
            viewer.setDocument(document, layerManager);
            updateStatus("DXF");
            showDiagnosticsIfNeeded();
            Toast.makeText(this,
                    "Đã đọc " + document.getEntities().size() + " đối tượng DXF",
                    Toast.LENGTH_LONG).show();
            return;
        }

        new AlertDialog.Builder(this)
                .setTitle("Định dạng chưa hỗ trợ")
                .setMessage("Không nhận dạng được file: " + displayName)
                .setPositiveButton("OK",null)
                .show();
    }

    private void openDxf() {
        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType("*/*");
        intent.putExtra(Intent.EXTRA_MIME_TYPES, new String[]{
                "application/dxf",
                "application/acad",
                "application/x-acad",
                "application/autocad_dwg",
                "image/vnd.dwg",
                "application/octet-stream",
                "text/plain"
        });
        startActivityForResult(intent, REQ_OPEN_DXF);
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode,resultCode,data);
        if (requestCode != REQ_OPEN_DXF || resultCode != RESULT_OK || data == null) return;

        Uri uri = data.getData();
        if (uri == null) return;

        try {
            final int flags = data.getFlags() &
                    (Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
            getContentResolver().takePersistableUriPermission(uri, flags);
        } catch (Exception ignored) {}

        recentDrawingStore.add(this, uri.toString());
        openCadUri(uri, "Bản vẽ đã chọn");
    }

    private void showMeasurements() {
        List<MeasurementResult> list = new MeasureEngine().collectAll(document);
        if (list.isEmpty()) {
            Toast.makeText(this,"Chưa có thông số để hiển thị",Toast.LENGTH_SHORT).show();
            return;
        }

        StringBuilder sb = new StringBuilder();
        int max = Math.min(list.size(), 80);
        for (int i=0;i<max;i++) {
            MeasurementResult r = list.get(i);
            sb.append(r.label).append(": ")
              .append(String.format(Locale.getDefault(),"%.3f",r.value))
              .append(" ").append(r.unit).append("\n");
        }
        if (list.size() > max) sb.append("... và ").append(list.size()-max).append(" thông số khác");

        new AlertDialog.Builder(this)
                .setTitle("HIỆN ĐẦY ĐỦ THÔNG SỐ")
                .setMessage(sb.toString())
                .setPositiveButton("OK",null)
                .show();
    }








    private void editGrip() {
        CadEntity e=viewer.getSelectedEntity();
        if(!(e instanceof com.dao.autocard.cad.model.LineEntity)) {
            Toast.makeText(this,"Hiện tại điểm chỉnh áp dụng trước cho đường thẳng",Toast.LENGTH_SHORT).show();
            return;
        }
        com.dao.autocard.cad.model.LineEntity line=(com.dao.autocard.cad.model.LineEntity)e;
        final android.widget.EditText input=new android.widget.EditText(this);
        input.setHint("x,y điểm cuối mới");
        new AlertDialog.Builder(this)
                .setTitle("ĐIỂM CHỈNH - ĐIỂM CUỐI ĐƯỜNG THẲNG")
                .setView(input)
                .setPositiveButton("Áp dụng",(d,w)->{
                    try{
                        String[] a=input.getText().toString().split(",");
                        double x=Double.parseDouble(a[0].trim());
                        double y=Double.parseDouble(a[1].trim());
                        com.dao.autocard.cad.model.LineEntity n=
                                new com.dao.autocard.cad.model.LineEntity(
                                        line.start,
                                        new com.dao.autocard.cad.model.Point2D(x,y));
                        n.setLayer(line.getLayer());
                        replaceSelected(n,"Chỉnh điểm đường thẳng");
                    }catch(Exception ex){
                        Toast.makeText(this,"Tọa độ không hợp lệ",Toast.LENGTH_SHORT).show();
                    }
                })
                .setNegativeButton("Hủy",null)
                .show();
    }

    private void offerRecoveryIfAvailable() {
        java.io.File recovery = recoveryManager.getRecoveryFile(this);
        if(recovery == null) return;

        new AlertDialog.Builder(this)
                .setTitle("PHỤC HỒI BẢN VẼ")
                .setMessage("Phát hiện bản autosave từ lần chỉnh sửa trước.")
                .setPositiveButton("Phục hồi",(d,w)->{
                    try(java.io.InputStream in=new java.io.FileInputStream(recovery)){
                        document=parser.parse(in);
                        layerManager.bindDocument(document);
                        commandHistory.clear();
                        viewer.setDocument(document,layerManager);
                    } catch(Exception e) {
                        Toast.makeText(this,"Không phục hồi được",Toast.LENGTH_LONG).show();
                    }
                })
                .setNegativeButton("Bỏ qua",null)
                .setNeutralButton("Xóa autosave",(d,w)->recoveryManager.clear(this))
                .show();
    }

    private void replaceSelected(CadEntity after,String label) {
        CadEntity before=viewer.getSelectedEntity();
        if(before==null || after==null) return;
        commandHistory.execute(new ReplaceEntityCommand(document,before,after,label));
        viewer.setSelectedEntity(after);
        layerManager.bindDocument(document);
        viewer.invalidate();
        try { recoveryManager.autosave(this,document); } catch(Exception ignored) {}
    }

    private void moveSelected() {
        CadEntity e=viewer.getSelectedEntity();
        if(e==null){ Toast.makeText(this,"Chọn đối tượng trước",Toast.LENGTH_SHORT).show(); return; }
        final android.widget.EditText input=new android.widget.EditText(this);
        input.setHint("dx,dy  ví dụ: 10,5");
        new AlertDialog.Builder(this).setTitle("DI CHUYỂN").setView(input)
                .setPositiveButton("Áp dụng",(d,w)->{
                    try{
                        String[] a=input.getText().toString().split(",");
                        double dx=Double.parseDouble(a[0].trim()),dy=Double.parseDouble(a[1].trim());
                        replaceSelected(geometryTransform.move(e,dx,dy),"Di chuyển");
                    }catch(Exception ex){ Toast.makeText(this,"Giá trị không hợp lệ",Toast.LENGTH_SHORT).show(); }
                }).setNegativeButton("Hủy",null).show();
    }

    private void rotateSelected() {
        CadEntity e=viewer.getSelectedEntity();
        if(e==null){ Toast.makeText(this,"Chọn đối tượng trước",Toast.LENGTH_SHORT).show(); return; }
        final android.widget.EditText input=new android.widget.EditText(this);
        input.setHint("Góc, ví dụ 90");
        new AlertDialog.Builder(this).setTitle("XOAY QUANH ĐIỂM TÂM").setView(input)
                .setPositiveButton("Áp dụng",(d,w)->{
                    try{
                        double a=Double.parseDouble(input.getText().toString().trim());
                        replaceSelected(geometryTransform.rotate(e,a,viewer.getPickedPivot()),"Xoay");
                    }catch(Exception ex){ Toast.makeText(this,"Giá trị không hợp lệ",Toast.LENGTH_SHORT).show(); }
                }).setNegativeButton("Hủy",null).show();
    }

    private void scaleSelected() {
        CadEntity e=viewer.getSelectedEntity();
        if(e==null){ Toast.makeText(this,"Chọn đối tượng trước",Toast.LENGTH_SHORT).show(); return; }
        final android.widget.EditText input=new android.widget.EditText(this);
        input.setHint("Hệ số, ví dụ 1.5");
        new AlertDialog.Builder(this).setTitle("THAY ĐỔI TỶ LỆ").setView(input)
                .setPositiveButton("Áp dụng",(d,w)->{
                    try{
                        double f=Double.parseDouble(input.getText().toString().trim());
                        replaceSelected(geometryTransform.scale(e,f,viewer.getPickedPivot()),"Tỷ lệ");
                    }catch(Exception ex){ Toast.makeText(this,"Giá trị không hợp lệ",Toast.LENGTH_SHORT).show(); }
                }).setNegativeButton("Hủy",null).show();
    }

    private void deleteSelected() {
        CadEntity e=viewer.getSelectedEntity();
        if(e==null){ Toast.makeText(this,"Chọn đối tượng trước",Toast.LENGTH_SHORT).show(); return; }
        commandHistory.execute(new DeleteEntityCommand(document,e));
        viewer.setSelectedEntity(null);
        layerManager.bindDocument(document);
        viewer.invalidate();
        try { recoveryManager.autosave(this,document); } catch(Exception ignored) {}
    }

    private void duplicateSelected() {
        CadEntity e=viewer.getSelectedEntity();
        if(e==null){ Toast.makeText(this,"Chọn đối tượng trước",Toast.LENGTH_SHORT).show(); return; }
        DuplicateEntityCommand c=new DuplicateEntityCommand(document,e);
        commandHistory.execute(c);
        viewer.setSelectedEntity(c.getCopy());
        layerManager.bindDocument(document);
        viewer.invalidate();
        try { recoveryManager.autosave(this,document); } catch(Exception ignored) {}
    }

    private void undoEdit() {
        String label = commandHistory.undo();
        if (label == null) {
            Toast.makeText(this,"Không có thao tác để hoàn tác",Toast.LENGTH_SHORT).show();
            return;
        }
        layerManager.bindDocument(document);
        viewer.invalidate();
        Toast.makeText(this,"Đã hoàn tác: " + label,Toast.LENGTH_SHORT).show();
    }

    private void redoEdit() {
        String label = commandHistory.redo();
        if (label == null) {
            Toast.makeText(this,"Không có thao tác để làm lại",Toast.LENGTH_SHORT).show();
            return;
        }
        layerManager.bindDocument(document);
        viewer.invalidate();
        Toast.makeText(this,"Đã làm lại: " + label,Toast.LENGTH_SHORT).show();
    }

    private void showRecentDrawings() {
        java.util.List<String> items = recentDrawingStore.get(this);
        if (items.isEmpty()) {
            Toast.makeText(this,"Chưa có bản vẽ gần đây",Toast.LENGTH_SHORT).show();
            return;
        }
        new AlertDialog.Builder(this)
                .setTitle("BẢN VẼ GẦN ĐÂY")
                .setItems(items.toArray(new String[0]),(d,which)->{
                    try {
                        android.net.Uri uri=android.net.Uri.parse(items.get(which));
                        openCadUri(uri, "Bản vẽ gần đây");
                    } catch(Exception ex) {
                        Toast.makeText(this,"Không mở lại được file",Toast.LENGTH_LONG).show();
                    }
                })
                .show();
    }

    private void saveDxf() {
        try {
            java.io.File dir = new java.io.File(getExternalFilesDir(null),"exports");
            if (!dir.exists()) dir.mkdirs();
            java.io.File file = new java.io.File(dir,"AutoCardDao_" + System.currentTimeMillis() + ".dxf");
            dxfWriter.write(document,file);
            lastExportedFile = file;
            lastExportMime = "application/dxf";
            new AlertDialog.Builder(this)
                    .setTitle("Lưu DXF thành công")
                    .setMessage(file.getAbsolutePath())
                    .setPositiveButton("OK",null)
                    .show();
        } catch(Exception e) {
            new AlertDialog.Builder(this)
                    .setTitle("Lưu DXF thất bại")
                    .setMessage(e.toString())
                    .setPositiveButton("OK",null)
                    .show();
        }
    }

    private void translateAllText() {
        viewer.getTranslationStore().clear();

        final android.app.ProgressDialog progress = new android.app.ProgressDialog(this);
        progress.setTitle("Đang dịch bản vẽ");
        progress.setMessage("Chuẩn bị...");
        progress.setIndeterminate(false);
        progress.setCancelable(false);
        progress.show();

        batchTranslationEngine.translateAll(document, viewer.getTranslationStore(),
                new BatchTranslationEngine.ProgressCallback() {
                    @Override public void onProgress(int completed, int total,
                                                     TextEntity entity,
                                                     TranslatedText result) {
                        runOnUiThread(() -> {
                            progress.setMessage(completed + "/" + total);
                            viewer.invalidate();
                        });
                    }

                    @Override public void onFinished(int total) {
                        runOnUiThread(() -> {
                            progress.dismiss();
                            Toast.makeText(MainActivity.this,
                                    "Đã xử lý " + total + " TEXT/MTEXT",
                                    Toast.LENGTH_LONG).show();
                            viewer.invalidate();
                        });
                    }
                });
    }

    private void chooseTextMode() {
        final TextDisplayMode[] modes = {
                TextDisplayMode.ORIGINAL,
                TextDisplayMode.BILINGUAL,
                TextDisplayMode.TRANSLATED
        };
        String[] labels = {"Gốc", "Song ngữ", "Đã dịch"};

        int checked = 0;
        TextDisplayMode current = viewer.getTextDisplayMode();
        for (int i=0;i<modes.length;i++) if (modes[i]==current) checked=i;

        new AlertDialog.Builder(this)
                .setTitle("CHẾ ĐỘ HIỂN THỊ VĂN BẢN")
                .setSingleChoiceItems(labels, checked, (d,which)->{
                    viewer.setTextDisplayMode(modes[which]);
                    d.dismiss();
                })
                .show();
    }

    private void shareLastExport() {
        if (lastExportedFile == null || !lastExportedFile.exists()) {
            Toast.makeText(this,"Chưa có file PNG/PDF để chia sẻ",Toast.LENGTH_SHORT).show();
            return;
        }
        try {
            shareHelper.shareFile(this,lastExportedFile,lastExportMime);
        } catch(Exception e) {
            new AlertDialog.Builder(this)
                    .setTitle("Không chia sẻ được")
                    .setMessage(e.toString())
                    .setPositiveButton("OK",null)
                    .show();
        }
    }

    private void editSelectedProperties() {
        CadEntity e = viewer.getSelectedEntity();
        if (e == null) {
            Toast.makeText(this,"Chọn một đối tượng trước",Toast.LENGTH_SHORT).show();
            return;
        }

        final android.widget.EditText input = new android.widget.EditText(this);
        input.setText(e.getLayer());
        input.setHint("Tên layer");

        new AlertDialog.Builder(this)
                .setTitle("THUỘC TÍNH ĐỐI TƯỢNG")
                .setMessage("Loại: " + e.getType() + "\nĐổi layer:")
                .setView(input)
                .setPositiveButton("Lưu",(d,w)->{
                    commandHistory.execute(new ChangeLayerCommand(e,input.getText().toString()));
                    layerManager.bindDocument(document);
                    viewer.invalidate();
                    try { recoveryManager.autosave(this,document); } catch(Exception ignored) {}
                })
                .setNegativeButton("Hủy",null)
                .show();
    }

    private void translateSelectedText() {
        CadEntity e = viewer.getSelectedEntity();
        if (!(e instanceof TextEntity)) {
            Toast.makeText(this,"Chọn văn bản trước",Toast.LENGTH_SHORT).show();
            return;
        }

        final TextEntity t=(TextEntity)e;
        translationEngine.translate(t, result -> runOnUiThread(() -> {
            new AlertDialog.Builder(this)
                    .setTitle("DỊCH VĂN BẢN")
                    .setMessage("Nguồn: " + result.sourceLanguage +
                            "\nĐích: " + result.targetLanguage +
                            "\n\nGốc:\n" + result.original +
                            "\n\nDịch:\n" + result.translated)
                    .setPositiveButton("OK",null)
                    .show();
        }));
    }

    private java.io.File makeExportFile(String extension) {
        java.io.File dir = new java.io.File(getExternalFilesDir(null),"exports");
        if (!dir.exists()) dir.mkdirs();
        return new java.io.File(dir,"AutoCardDao_" + System.currentTimeMillis() + extension);
    }

    private void exportPng() {
        try {
            java.io.File file = exportEngine.exportPng(viewer,makeExportFile(".png"));
            lastExportedFile = file;
            lastExportMime = "image/png";
            new AlertDialog.Builder(this)
                    .setTitle("Xuất PNG thành công")
                    .setMessage(file.getAbsolutePath())
                    .setPositiveButton("OK",null)
                    .show();
        } catch(Exception e) {
            new AlertDialog.Builder(this)
                    .setTitle("Xuất PNG thất bại")
                    .setMessage(e.toString())
                    .setPositiveButton("OK",null)
                    .show();
        }
    }

    private void exportPdf() {
        try {
            java.io.File file = exportEngine.exportPdf(viewer,makeExportFile(".pdf"));
            lastExportedFile = file;
            lastExportMime = "application/pdf";
            new AlertDialog.Builder(this)
                    .setTitle("Xuất PDF thành công")
                    .setMessage(file.getAbsolutePath())
                    .setPositiveButton("OK",null)
                    .show();
        } catch(Exception e) {
            new AlertDialog.Builder(this)
                    .setTitle("Xuất PDF thất bại")
                    .setMessage(e.toString())
                    .setPositiveButton("OK",null)
                    .show();
        }
    }

    private void showSelectedEntity() {
        com.dao.autocard.cad.model.CadEntity e = viewer.getSelectedEntity();
        if (e == null) {
            Toast.makeText(this,"Chạm vào đối tượng trên bản vẽ trước",Toast.LENGTH_SHORT).show();
            return;
        }
        StringBuilder sb = new StringBuilder();
        sb.append("Loại: ").append(e.getType()).append("\n");
        sb.append("Layer: ").append(e.getLayer()).append("\n");

        if (e instanceof com.dao.autocard.cad.model.LineEntity) {
            com.dao.autocard.cad.model.LineEntity x=(com.dao.autocard.cad.model.LineEntity)e;
            sb.append("Chiều dài: ").append(String.format(java.util.Locale.getDefault(),"%.3f",x.length()));
        } else if (e instanceof com.dao.autocard.cad.model.CircleEntity) {
            com.dao.autocard.cad.model.CircleEntity x=(com.dao.autocard.cad.model.CircleEntity)e;
            sb.append("Bán kính: ").append(String.format(java.util.Locale.getDefault(),"%.3f",x.radius));
        } else if (e instanceof com.dao.autocard.cad.model.ArcEntity) {
            com.dao.autocard.cad.model.ArcEntity x=(com.dao.autocard.cad.model.ArcEntity)e;
            sb.append("Góc cung: ").append(String.format(java.util.Locale.getDefault(),"%.2f°",x.sweepDeg()));
        } else if (e instanceof com.dao.autocard.cad.model.TextEntity) {
            sb.append("Nội dung: ").append(((com.dao.autocard.cad.model.TextEntity)e).text);
        } else if (e instanceof com.dao.autocard.cad.model.InsertEntity) {
            sb.append("Block: ").append(((com.dao.autocard.cad.model.InsertEntity)e).blockName);
        }

        new AlertDialog.Builder(this)
                .setTitle("THÔNG TIN CHI TIẾT")
                .setMessage(sb.toString())
                .setPositiveButton("OK",null)
                .show();
    }

    private void showLayers() {
        final List<String> names = new ArrayList<>(layerManager.getLayerNames());
        if (names.isEmpty()) {
            Toast.makeText(this,"Bản vẽ chưa có layer",Toast.LENGTH_SHORT).show();
            return;
        }

        boolean[] checked = new boolean[names.size()];
        for (int i=0;i<names.size();i++) checked[i]=layerManager.isVisible(names.get(i));

        new AlertDialog.Builder(this)
                .setTitle("LỚP")
                .setMultiChoiceItems(names.toArray(new String[0]),checked,(d,which,isChecked)->{
                    layerManager.setVisible(names.get(which),isChecked);
                    viewer.invalidate();
                })
                .setPositiveButton("Xong",null)
                .setNeutralButton("Hiện tất cả",(d,w)->{
                    layerManager.showAll(); viewer.invalidate();
                })
                .setNegativeButton("Ẩn tất cả",(d,w)->{
                    layerManager.hideAll(); viewer.invalidate();
                })
                .show();
    }
}
