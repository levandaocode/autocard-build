package com.dao.autocard.cad.library;

import android.content.Context;
import android.content.SharedPreferences;
import java.util.*;

public final class DrawingLibraryStore {
    private static final String PREF="drawing_library_v1";
    private static final String RECENT="recent";
    private static final String FAVORITE="favorite";
    private static final String ARCHIVE="archive";

    private SharedPreferences p(Context c){ return c.getSharedPreferences(PREF,Context.MODE_PRIVATE); }

    public List<String> recent(Context c){ return read(p(c).getString(RECENT,"")); }
    public List<String> favorites(Context c){ return read(p(c).getString(FAVORITE,"")); }
    public List<String> archive(Context c){ return read(p(c).getString(ARCHIVE,"")); }

    public void touch(Context c,String path){
        List<String> a=recent(c); a.remove(path); a.add(0,path);
        while(a.size()>50) a.remove(a.size()-1);
        write(c,RECENT,a);
    }

    public void removeRecent(Context c,String path){
        List<String>a=recent(c); a.remove(path); write(c,RECENT,a);
    }

    public void toggleFavorite(Context c,String path){
        List<String>a=favorites(c);
        if(a.contains(path)) a.remove(path); else a.add(0,path);
        write(c,FAVORITE,a);
    }

    public void toggleArchive(Context c,String path){
        List<String>a=archive(c);
        if(a.contains(path)) a.remove(path); else a.add(0,path);
        write(c,ARCHIVE,a);
    }

    public boolean isFavorite(Context c,String path){ return favorites(c).contains(path); }
    public boolean isArchived(Context c,String path){ return archive(c).contains(path); }

    public List<String> search(Context c,String q){
        q=q==null?"":q.trim().toLowerCase(Locale.ROOT);
        LinkedHashSet<String> all=new LinkedHashSet<>();
        all.addAll(recent(c)); all.addAll(favorites(c)); all.addAll(archive(c));
        List<String> out=new ArrayList<>();
        for(String x:all) if(x.toLowerCase(Locale.ROOT).contains(q)) out.add(x);
        return out;
    }

    public void replacePath(Context c,String oldPath,String newPath){
        replace(c,RECENT,oldPath,newPath);
        replace(c,FAVORITE,oldPath,newPath);
        replace(c,ARCHIVE,oldPath,newPath);
    }

    private void replace(Context c,String key,String oldPath,String newPath){
        List<String>a=read(p(c).getString(key,""));
        int i=a.indexOf(oldPath);
        if(i>=0){ a.set(i,newPath); write(c,key,a); }
    }

    private void write(Context c,String key,List<String>a){
        StringBuilder sb=new StringBuilder();
        for(String x:a){
            if(x==null) continue;
            if(sb.length()>0) sb.append("\n");
            sb.append(x.replace("\n",""));
        }
        p(c).edit().putString(key,sb.toString()).apply();
    }

    private List<String> read(String s){
        List<String>a=new ArrayList<>();
        if(s==null||s.isEmpty()) return a;
        for(String x:s.split("\n")) if(!x.trim().isEmpty()) a.add(x.trim());
        return a;
    }
}
