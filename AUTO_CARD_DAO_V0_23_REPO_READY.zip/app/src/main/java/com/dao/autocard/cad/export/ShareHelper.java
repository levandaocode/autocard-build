package com.dao.autocard.cad.export;

import android.app.Activity;
import android.app.AlertDialog;
import java.io.File;

public final class ShareHelper {
    public void shareFile(Activity activity, File file, String mimeType) {
        if (activity == null || file == null || !file.exists()) return;
        new AlertDialog.Builder(activity)
                .setTitle("FILE ĐÃ XUẤT")
                .setMessage(file.getAbsolutePath())
                .setPositiveButton("OK", null)
                .show();
    }
}
