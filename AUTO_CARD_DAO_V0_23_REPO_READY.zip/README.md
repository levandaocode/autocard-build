# AUTO CARD ĐẠO V0.23 — NATIVE/JNI CHECKPOINT

## Đã thêm
- `app/src/main/cpp/CMakeLists.txt`
- `dwg_native.cpp`
- `DwgNativeBridge.java`
- `DwgNativeEngine.java`
- JNI contract ổn định cho DWG native.
- CMake cấu hình `-O3`, C++17 và loại bỏ code thừa khi link.
- Tự đăng ký `DwgNativeEngine` khi `libautocard_dwg.so` nạp thành công.

## Trạng thái
Đây là khung native thật, nhưng chưa chứa decoder DWG đầy đủ.
Nó cố tình không báo thành công giả khi chưa giải mã entity.

## Bước kế tiếp
Khi có Android NDK r29:
1. Build `libautocard_dwg.so` cho arm64-v8a trước.
2. Test JNI trên APK.
3. Cấy decoder DWG AC1015 vào `dwg_native.cpp`/native library.
4. Map entity native -> model Java hiện tại.
