#!/usr/bin/env bash
set -euo pipefail

ROOT="$(cd "$(dirname "$0")" && pwd)"
TOOLS="${ANDROID_BUILD_TOOLS:-/mnt/data/android_tools/build35/android-15}"
ANDROID_JAR="${ANDROID_JAR:-/mnt/data/android_tools/android.jar}"
OUT="$ROOT/manual-build"

if [ ! -f "$ANDROID_JAR" ]; then
  echo "MISSING: $ANDROID_JAR"
  echo "Provide Android SDK Platform android.jar (API 35 recommended)."
  exit 2
fi

rm -rf "$OUT"
mkdir -p "$OUT/classes" "$OUT/dex" "$OUT/res-compiled"

"$TOOLS/aapt2" compile --dir "$ROOT/app/src/main/res" -o "$OUT/res.zip"

"$TOOLS/aapt2" link   -I "$ANDROID_JAR"   --manifest "$ROOT/app/src/main/AndroidManifest.xml"   --java "$OUT/generated"   --min-sdk-version 23   --target-sdk-version 35   -o "$OUT/resources.apk"   "$OUT/res.zip"

find "$ROOT/app/src/main/java" "$OUT/generated" -name '*.java' > "$OUT/sources.txt"

javac -source 8 -target 8 -encoding UTF-8   -classpath "$ANDROID_JAR"   -d "$OUT/classes"   @"$OUT/sources.txt"

(cd "$OUT/classes" && jar cf "$OUT/classes.jar" .)
"$TOOLS/d8" --lib "$ANDROID_JAR" --min-api 23 --output "$OUT/dex" "$OUT/classes.jar"

cp "$OUT/resources.apk" "$OUT/unsigned.apk"
(cd "$OUT/dex" && zip -q -u "$OUT/unsigned.apk" classes.dex)

"$TOOLS/zipalign" -f 4 "$OUT/unsigned.apk" "$OUT/aligned.apk"

echo "Built: $OUT/aligned.apk"
echo "Sign with apksigner + CAD_RECODE_NEW_RELEASE.p12."
