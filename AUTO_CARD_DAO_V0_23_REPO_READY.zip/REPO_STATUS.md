# AUTO CARD ĐẠO — Repository status

Current checkpoint: V0.23 Native/JNI.

Included:
- Android Java source
- DXF parser/viewer/editor modules
- DWG offline/native bridge scaffolding
- CMake/C++ JNI code
- Android resources and launcher icons
- Build scripts and project configuration

Important:
- Full DWG AC1015 decoder is not yet bundled.
- `app/src/main/assets/dwg/acad-engine.js` is still pending.
- Do not treat the current JNI placeholder as a complete DWG decoder.
